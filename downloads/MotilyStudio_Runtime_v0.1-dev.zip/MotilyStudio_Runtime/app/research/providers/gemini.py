"""Gemini + Google Search implementation of :class:`ResearchRetriever`.

The provider uses Gemini's Google Search grounding tool only as a retrieval
transport. Research engines still receive provider-independent ``RetrievedSource``
objects and remain solely responsible for evidence quality/business validation.
"""

from __future__ import annotations

import os
import time
from typing import Any, Callable

import httpx
from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types
from pydantic import model_validator

from app.models.common import MotilyModel, non_blank
from app.research.errors import (
    ResearchRetrieverAuthenticationError,
    ResearchRetrieverConfigurationError,
    ResearchRetrieverError,
    ResearchRetrieverRateLimitError,
    ResearchRetrieverResponseError,
    ResearchRetrieverTimeoutError,
    ResearchRetrieverTransportError,
)
from app.research.models import ResearchQuery, ResearchSearchResponse, RetrievedSource

GEMINI_SEARCH_PROVIDER_NAME = "gemini_google_search"
DEFAULT_GEMINI_SEARCH_MODEL = "gemini-3.6-flash"


class GeminiSearchConfig(MotilyModel):
    api_key_env: str = "GEMINI_API_KEY"
    model: str = DEFAULT_GEMINI_SEARCH_MODEL
    timeout_seconds: float = 60.0
    max_provider_retries: int = 1
    retry_backoff_seconds: float = 0.25

    @model_validator(mode="after")
    def _check_invariants(self) -> "GeminiSearchConfig":
        non_blank(self.api_key_env, "api_key_env")
        non_blank(self.model, "model")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        if self.max_provider_retries < 0:
            raise ValueError("max_provider_retries must be >= 0")
        if self.retry_backoff_seconds < 0:
            raise ValueError("retry_backoff_seconds must be >= 0")
        return self

    def __repr__(self) -> str:
        return (
            "GeminiSearchConfig("
            f"api_key_env={self.api_key_env!r}, model={self.model!r}, "
            f"timeout_seconds={self.timeout_seconds!r}, "
            f"max_provider_retries={self.max_provider_retries!r}, "
            f"retry_backoff_seconds={self.retry_backoff_seconds!r})"
        )


class GeminiSearchRetriever:
    """Synchronous Google-Search-grounded research retriever.

    A client may be injected for deterministic tests. With no injected client,
    credentials are read from ``config.api_key_env`` exactly once while building
    the SDK client. The key itself is never stored in Motily models or messages.
    """

    def __init__(
        self,
        config: GeminiSearchConfig | None = None,
        *,
        client: Any = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._config = config or GeminiSearchConfig()
        self._client = client if client is not None else _build_default_client(self._config)
        self._sleep = sleep

    @property
    def config(self) -> GeminiSearchConfig:
        return self._config

    def search(self, query: ResearchQuery) -> ResearchSearchResponse:
        attempts = self._config.max_provider_retries + 1
        for attempt in range(1, attempts + 1):
            try:
                response = self._client.models.generate_content(
                    model=self._config.model,
                    contents=_build_search_prompt(query),
                    config=_build_generate_config(),
                )
                results = _extract_sources(response, query.max_results)
                return ResearchSearchResponse(query=query, results=results)
            except Exception as exc:  # narrowed immediately below
                if isinstance(exc, ResearchRetrieverError):
                    raise
                mapped, retryable = _classify_exception(exc)
                if mapped is None:
                    raise
                if retryable and attempt < attempts:
                    if self._config.retry_backoff_seconds:
                        self._sleep(self._config.retry_backoff_seconds * attempt)
                    continue
                raise mapped from exc

        raise AssertionError("unreachable: Gemini search retry loop exited without result")

    def __repr__(self) -> str:
        return f"GeminiSearchRetriever(config={self._config!r})"


def _build_default_client(config: GeminiSearchConfig) -> genai.Client:
    api_key = os.environ.get(config.api_key_env)
    if not api_key:
        raise ResearchRetrieverConfigurationError(
            f"Environment variable {config.api_key_env!r} is not set; "
            "GeminiSearchRetriever requires a Gemini API key"
        )
    return genai.Client(
        api_key=api_key,
        http_options=genai_types.HttpOptions(timeout=int(config.timeout_seconds * 1000)),
    )


def _build_search_prompt(query: ResearchQuery) -> str:
    # Grounding metadata, not model-authored prose, is the source of URLs below.
    # Keeping this prompt narrow reduces irrelevant search-query expansion while
    # allowing Gemini Search to find authoritative pages for the engine's query.
    return (
        "Search the web for reliable sources relevant to this research query. "
        "Prefer primary, institutional, academic, or otherwise authoritative sources. "
        f"Research query: {query.query}"
    )


def _build_generate_config() -> genai_types.GenerateContentConfig:
    return genai_types.GenerateContentConfig(
        tools=[genai_types.Tool(google_search=genai_types.GoogleSearch())],
        temperature=0,
        max_output_tokens=256,
    )


def _extract_sources(response: Any, max_results: int) -> list[RetrievedSource]:
    candidates = getattr(response, "candidates", None) or []
    if not candidates:
        raise ResearchRetrieverResponseError("Gemini search response contained no candidates")

    grounding = getattr(candidates[0], "grounding_metadata", None)
    if grounding is None:
        raise ResearchRetrieverResponseError(
            "Gemini search response contained no Google Search grounding metadata"
        )

    chunks = getattr(grounding, "grounding_chunks", None) or []
    results: list[RetrievedSource] = []
    seen_urls: set[str] = set()

    for chunk in chunks:
        web = getattr(chunk, "web", None)
        if web is None:
            continue
        uri = str(getattr(web, "uri", "") or "").strip()
        title = str(getattr(web, "title", "") or "").strip()
        domain = str(getattr(web, "domain", "") or "").strip()
        if not uri:
            continue
        if uri in seen_urls:
            continue
        if not title:
            title = domain or uri

        metadata = {"retrieval_provider": GEMINI_SEARCH_PROVIDER_NAME}
        results.append(
            RetrievedSource(
                title=title,
                url=uri,
                source_name=domain or None,
                metadata=metadata,
            )
        )
        seen_urls.add(uri)
        if len(results) >= max_results:
            break

    # An empty, valid search result set is allowed by the ResearchRetriever
    # contract. Engines already own the business judgment of whether evidence is
    # sufficient; only malformed/missing grounding metadata is a provider error.
    return results


def _classify_exception(exc: Exception) -> tuple[ResearchRetrieverError | None, bool]:
    if isinstance(exc, httpx.TimeoutException):
        return ResearchRetrieverTimeoutError("Gemini Search request timed out"), True
    if isinstance(exc, httpx.TransportError):
        return ResearchRetrieverTransportError("Gemini Search transport request failed"), True
    if isinstance(exc, genai_errors.APIError):
        code = int(getattr(exc, "code", 0) or 0)
        status = getattr(exc, "status", None)
        suffix = f" ({code}{' ' + str(status) if status else ''})" if code or status else ""
        if code in (401, 403):
            return ResearchRetrieverAuthenticationError(
                f"Gemini Search authentication/authorization failed{suffix}"
            ), False
        if code == 429:
            return ResearchRetrieverRateLimitError(
                f"Gemini Search rate limit exceeded{suffix}"
            ), True
        if 500 <= code < 600:
            return ResearchRetrieverError(
                f"Gemini Search provider temporarily failed{suffix}"
            ), True
        return ResearchRetrieverError(f"Gemini Search provider request failed{suffix}"), False
    return None, False
