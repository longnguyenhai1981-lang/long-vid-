class EvidenceMediaError(Exception):
    """Base class for deterministic evidence-media binding/materialization failures."""


class EvidenceSourceNotFoundError(EvidenceMediaError):
    pass


class EvidenceAssetTypeError(EvidenceMediaError):
    pass


class EvidenceAssetProjectMismatchError(EvidenceMediaError):
    pass


class EvidenceMediaUnsupportedFormatError(EvidenceMediaError):
    pass


class EvidenceMediaFileMissingError(EvidenceMediaError):
    pass


class EvidenceMediaUnreadableError(EvidenceMediaError):
    pass
