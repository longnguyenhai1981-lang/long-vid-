"""Gemini API Veo 3.1 provider for rare AI_HERO_VIDEO beats.

Uses google-genai's long-running `models.generate_videos()` API, polls the
returned operation deterministically, downloads exactly the first generated
video, and returns MP4 bytes to the provider-neutral HeroVideoProvider
boundary. No retry loop lives here: VisualRenderer owns bounded retries for
HeroVideoProviderError, matching the existing image-provider architecture.
"""

from __future__ import annotations

import io
import os
import time
from collections.abc import Callable

import httpx
from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types
from pydantic import model_validator

from app.hero_video.errors import (
    HeroVideoConfigurationError,
    HeroVideoOutputError,
    HeroVideoProviderError,
)
from app.hero_video.models import HeroVideoRenderRequest, HeroVideoRenderResponse
from app.models.common import MotilyModel, non_blank

GEMINI_VEO_PROVIDER_NAME = "gemini-veo"
DEFAULT_GEMINI_VEO_MODEL = "veo-3.1-lite-generate-preview"

_RETRYABLE_SDK_ERRORS = (genai_errors.APIError, httpx.HTTPError)


class GeminiVeoConfig(MotilyModel):
    model: str = DEFAULT_GEMINI_VEO_MODEL
    api_key_env: str = "GEMINI_API_KEY"
    poll_interval_seconds: float = 10.0
    max_wait_seconds: float = 300.0
    default_aspect_ratio: str = "16:9"
    default_resolution: str = "720p"

    @model_validator(mode="after")
    def _check_invariants(self) -> "GeminiVeoConfig":
        non_blank(self.model, "model")
        non_blank(self.api_key_env, "api_key_env")
        if self.poll_interval_seconds <= 0:
            raise ValueError("poll_interval_seconds must be > 0")
        if self.max_wait_seconds <= 0:
            raise ValueError("max_wait_seconds must be > 0")
        if self.default_aspect_ratio not in {"16:9", "9:16"}:
            raise ValueError("default_aspect_ratio must be '16:9' or '9:16'")
        if self.default_resolution not in {"720p", "1080p", "4k"}:
            raise ValueError("default_resolution must be one of '720p', '1080p', '4k'")
        if "lite" in self.model.lower() and self.default_resolution == "4k":
            raise ValueError("Veo 3.1 Lite does not support 4k output")
        return self


class GeminiVeoProvider:
    def __init__(
        self,
        config: GeminiVeoConfig,
        *,
        client=None,
        sleeper: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.monotonic,
    ):
        self._config = config
        self._client = client if client is not None else _build_default_client(config)
        self._sleeper = sleeper
        self._clock = clock

    def render(self, request: HeroVideoRenderRequest) -> HeroVideoRenderResponse:
        if "lite" in self._config.model.lower() and request.resolution == "4k":
            raise HeroVideoOutputError("Configured Veo Lite model does not support 4k output")

        prompt = _build_prompt(request)
        try:
            operation = self._client.models.generate_videos(
                model=self._config.model,
                prompt=prompt,
                config=genai_types.GenerateVideosConfig(
                    aspect_ratio=request.aspect_ratio or self._config.default_aspect_ratio,
                    resolution=request.resolution or self._config.default_resolution,
                    number_of_videos=1,
                ),
            )
            start = self._clock()
            while not bool(getattr(operation, "done", False)):
                if self._clock() - start >= self._config.max_wait_seconds:
                    raise HeroVideoProviderError(
                        f"Gemini Veo generation timed out after {self._config.max_wait_seconds:g}s"
                    )
                self._sleeper(self._config.poll_interval_seconds)
                operation = self._client.operations.get(operation)
        except HeroVideoProviderError:
            raise
        except _RETRYABLE_SDK_ERRORS as exc:
            raise HeroVideoProviderError(_safe_provider_error_message(exc)) from exc

        response = getattr(operation, "response", None) or getattr(operation, "result", None)
        generated_videos = getattr(response, "generated_videos", None) if response is not None else None
        if not generated_videos:
            reasons = getattr(response, "rai_media_filtered_reasons", None) if response is not None else None
            reason_text = f"; reasons={reasons}" if reasons else ""
            raise HeroVideoOutputError(f"Gemini Veo returned no generated video{reason_text}")

        generated = generated_videos[0]
        video = getattr(generated, "video", None)
        if video is None:
            raise HeroVideoOutputError("Gemini Veo generated_videos[0] contained no video")

        mime_type = getattr(video, "mime_type", None) or "video/mp4"
        if mime_type != "video/mp4":
            raise HeroVideoOutputError(
                f"Gemini Veo returned unsupported MIME type {mime_type!r}; expected 'video/mp4'"
            )

        video_bytes = getattr(video, "video_bytes", None)
        if not video_bytes:
            buffer = io.BytesIO()
            try:
                downloaded = self._client.files.download(file=video, destination=buffer)
            except _RETRYABLE_SDK_ERRORS as exc:
                raise HeroVideoProviderError(_safe_provider_error_message(exc)) from exc
            video_bytes = buffer.getvalue() or downloaded

        if not video_bytes:
            raise HeroVideoOutputError("Gemini Veo video download returned no bytes")

        return HeroVideoRenderResponse(
            video_bytes=bytes(video_bytes),
            provider=GEMINI_VEO_PROVIDER_NAME,
            model=self._config.model,
            provider_request_id=getattr(operation, "name", None),
            mime_type="video/mp4",
            metadata={
                "aspect_ratio": request.aspect_ratio,
                "resolution": request.resolution,
            },
        )


def _build_default_client(config: GeminiVeoConfig) -> genai.Client:
    api_key = os.environ.get(config.api_key_env)
    if not api_key:
        raise HeroVideoConfigurationError(
            f"Environment variable {config.api_key_env!r} is not set; "
            "GeminiVeoProvider requires a Gemini API key"
        )
    return genai.Client(api_key=api_key)


def _build_prompt(request: HeroVideoRenderRequest) -> str:
    lines = [
        "Create one short cinematic hero shot for a science explainer video.",
        f"PRIMARY FOCUS: {request.primary_focus}",
        f"CONCEPT: {request.concept}",
    ]
    if request.secondary_elements:
        lines.append(f"SECONDARY ELEMENTS: {', '.join(request.secondary_elements)}")
    if request.context_elements:
        lines.append(f"CONTEXT: {', '.join(request.context_elements)}")
    if request.motion_intent:
        lines.append(f"MOTION: {request.motion_intent}")
    lines.append("Do not add subtitles, captions, logos, watermarks, or explanatory text.")
    return "\n".join(lines)


def _safe_provider_error_message(exc: Exception) -> str:
    if isinstance(exc, genai_errors.APIError):
        message = f"Gemini Veo API error {exc.code} ({exc.status}): {exc.message or 'no message'}"
    else:
        message = f"Gemini Veo network error: {type(exc).__name__}"
    return message[:500]
