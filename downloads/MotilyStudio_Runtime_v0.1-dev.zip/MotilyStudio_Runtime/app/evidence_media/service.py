"""Evidence-source -> local media binding using the existing workspace store.

A ResearchPackage source is factual provenance; a WorkspaceAsset is the exact
local media file.  Binding them is explicit and durable through
WorkspaceAssetSelection.  No filename inference, web scraping, OCR, or LLM use
occurs here.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.engines.research_r1.models import RESEARCH_R1_ARTIFACT_TYPE
from app.engines.visual_plan.models import VISUAL_PLAN_ARTIFACT_TYPE
from app.evidence_media.errors import (
    EvidenceAssetProjectMismatchError,
    EvidenceAssetTypeError,
    EvidenceMediaFileMissingError,
    EvidenceMediaUnsupportedFormatError,
    EvidenceSourceNotFoundError,
)
from app.evidence_media.models import EvidenceMediaSource
from app.models.common import VisualMediaType
from app.models.research import ResearchPackage
from app.models.visual import VisualPlan
from app.storage.artifacts import get_artifact
from app.storage.errors import ArtifactNotFoundError
from app.storage.workspace_assets import (
    get_workspace_asset,
    get_workspace_asset_selection,
    save_workspace_asset_selection,
)
from app.workspace.ingest import ingest_workspace_file
from app.workspace.models import AssetOrigin, WorkspaceAssetSelection, WorkspaceAssetType
from app.workspace.storage import WorkspaceBlobStore

_SUPPORTED_EVIDENCE_IMAGE_EXTENSIONS = frozenset({"png", "jpg", "jpeg", "webp"})
_SUPPORTED_EVIDENCE_VIDEO_EXTENSIONS = frozenset({"mp4", "mov"})
_SUPPORTED_EVIDENCE_EXTENSIONS = _SUPPORTED_EVIDENCE_IMAGE_EXTENSIONS | _SUPPORTED_EVIDENCE_VIDEO_EXTENSIONS
_ROLE_PREFIX = "EVIDENCE_SOURCE:"


def evidence_selection_role(source_id: str) -> str:
    return f"{_ROLE_PREFIX}{source_id}"


def _load_current_research(engine: Engine, project_id: UUID) -> ResearchPackage:
    try:
        return get_artifact(engine, project_id, RESEARCH_R1_ARTIFACT_TYPE, ResearchPackage)
    except ArtifactNotFoundError as exc:
        raise EvidenceSourceNotFoundError(
            f"Project {project_id} has no current ResearchPackage; evidence cannot be bound yet"
        ) from exc


def bind_local_evidence_media(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
    source_id: str,
    source_path: Path | str,
):
    research = _load_current_research(engine, project_id)
    if source_id not in {source.source_id for source in research.sources}:
        raise EvidenceSourceNotFoundError(
            f"ResearchPackage {research.id} has no source_id {source_id!r}"
        )
    path = Path(source_path)
    extension = path.suffix.lstrip(".").lower()
    if extension not in _SUPPORTED_EVIDENCE_EXTENSIONS:
        raise EvidenceMediaUnsupportedFormatError(
            "Evidence media must be a supported local image/video; expected one of "
            f"{sorted(_SUPPORTED_EVIDENCE_EXTENSIONS)}, got {extension!r}"
        )

    asset = ingest_workspace_file(
        engine,
        blob_store,
        project_id=project_id,
        source_path=path,
        asset_type=WorkspaceAssetType.EVIDENCE_MEDIA,
        origin=AssetOrigin.USER_PROVIDED,
        logical_name=source_id,
        note=f"Evidence media bound to ResearchPackage {research.id} source {source_id}",
    )
    save_workspace_asset_selection(
        engine,
        WorkspaceAssetSelection(
            project_id=project_id,
            role=evidence_selection_role(source_id),
            asset_id=asset.id,
            updated_at=datetime.now(timezone.utc),
        ),
    )
    return asset


def resolve_evidence_media_sources(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
) -> tuple[dict[str, EvidenceMediaSource], str | None]:
    """Resolve explicit source bindings for the current VisualPlan.

    For a beat citing multiple sources, the first *authored* source_id with a
    bound local evidence image wins.  If none are bound the beat is simply
    omitted from the returned mapping and VisualRenderer preserves its honest
    EXTERNAL_REQUIRED requirement.
    """
    try:
        research = get_artifact(engine, project_id, RESEARCH_R1_ARTIFACT_TYPE, ResearchPackage)
        visual_plan = get_artifact(engine, project_id, VISUAL_PLAN_ARTIFACT_TYPE, VisualPlan)
    except ArtifactNotFoundError:
        return {}, None

    valid_source_ids = {source.source_id for source in research.sources}
    resolved: dict[str, EvidenceMediaSource] = {}
    fingerprint_parts: list[str] = []

    for beat in visual_plan.beats:
        if beat.media_type is not VisualMediaType.EVIDENCE_MEDIA:
            continue
        for source_id in beat.evidence_source_ids:
            if source_id not in valid_source_ids:
                continue  # VisualPlan validation should already forbid this.
            selection = get_workspace_asset_selection(
                engine, project_id, evidence_selection_role(source_id)
            )
            if selection is None:
                continue
            asset = get_workspace_asset(engine, selection.asset_id)
            if asset.project_id != project_id:
                raise EvidenceAssetProjectMismatchError(
                    f"Evidence asset {asset.id} belongs to {asset.project_id}, expected {project_id}"
                )
            if asset.asset_type is not WorkspaceAssetType.EVIDENCE_MEDIA:
                raise EvidenceAssetTypeError(
                    f"Evidence binding for source {source_id!r} points to asset type {asset.asset_type.value}"
                )
            if asset.media_type not in _SUPPORTED_EVIDENCE_EXTENSIONS:
                continue
            path = blob_store.resolve(asset.stored_relative_path)
            if not path.is_file():
                raise EvidenceMediaFileMissingError(
                    f"Evidence asset {asset.id} points to missing workspace blob {path}"
                )
            resolved[beat.beat_id] = EvidenceMediaSource(
                source_id=source_id,
                file_path=path,
                workspace_asset_id=asset.id,
                media_type=asset.media_type,
            )
            fingerprint_parts.append(
                f"{beat.beat_id}:{source_id}:{selection.asset_id}:{asset.sha256}"
            )
            break

    if not fingerprint_parts:
        return resolved, None
    digest = hashlib.sha256("\n".join(sorted(fingerprint_parts)).encode("utf-8")).hexdigest()
    return resolved, digest


# Backward-compatible Phase 40 name.
bind_local_evidence_image = bind_local_evidence_media
