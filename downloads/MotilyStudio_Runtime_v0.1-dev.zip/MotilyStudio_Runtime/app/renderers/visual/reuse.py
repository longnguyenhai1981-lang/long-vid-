"""Deterministic ASSET_REUSE binding helpers (Phase 41).

`reuse_key` is authored planning metadata, not a fuzzy asset lookup query.  In
production we resolve it only when the current VisualPlan contains exactly one
non-ASSET_REUSE beat declaring the same key.  That exact beat id becomes the
source.  Missing producers remain unresolved (the legacy REUSE_ONLY requirement
is preserved); ambiguous producers fail explicitly rather than guessing.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

from app.models.common import VisualMediaType
from app.models.visual import VisualPlan
from app.renderers.visual.errors import AmbiguousAssetReuseKeyError
from app.renderers.visual.models import AssetReuseSource


def derive_asset_reuse_sources(
    visual_plan: VisualPlan,
) -> tuple[dict[str, AssetReuseSource], str | None]:
    """Derive exact `reuse_key -> source_beat_id` bindings from a VisualPlan.

    Only non-ASSET_REUSE beats may act as automatic producers.  A missing
    producer is intentionally omitted so the renderer keeps the honest
    REUSE_ONLY requirement.  More than one producer for the same key is an
    authoring ambiguity and therefore a hard error.
    """

    producers: dict[str, list[str]] = {}
    requested_keys: set[str] = set()

    for beat in visual_plan.beats:
        key = (beat.reuse_key or "").strip()
        if not key:
            continue
        if beat.media_type is VisualMediaType.ASSET_REUSE:
            requested_keys.add(key)
        else:
            producers.setdefault(key, []).append(beat.beat_id)

    resolved: dict[str, AssetReuseSource] = {}
    for key in sorted(requested_keys):
        matches = producers.get(key, [])
        if len(matches) > 1:
            raise AmbiguousAssetReuseKeyError(
                f"reuse_key {key!r} has multiple producer beats {matches}; "
                "ASSET_REUSE requires one exact producer"
            )
        if len(matches) == 1:
            resolved[key] = AssetReuseSource(source_beat_id=matches[0])

    return resolved, fingerprint_asset_reuse_sources(resolved)


def fingerprint_asset_reuse_sources(
    sources: dict[str, AssetReuseSource],
) -> str | None:
    """Stable identity of exact reuse bindings.

    Beat references are identified by beat id.  Explicit path bindings include
    the file's full SHA-256 so replacing bytes at the same path invalidates the
    render manifest instead of silently reusing stale output.
    """

    if not sources:
        return None

    parts: list[str] = []
    for key in sorted(sources):
        source = sources[key]
        if source.source_beat_id is not None:
            parts.append(f"{key}:beat:{source.source_beat_id}")
            continue
        assert source.source_path is not None
        path = Path(source.source_path)
        if path.is_file():
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            parts.append(f"{key}:path-sha256:{digest}")
        else:
            # Missing-file validation happens at materialization; include the
            # resolved path so even the failing input has deterministic identity.
            parts.append(f"{key}:missing-path:{path.resolve(strict=False)}")

    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()
