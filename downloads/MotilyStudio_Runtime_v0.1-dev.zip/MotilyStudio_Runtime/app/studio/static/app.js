
const ONBOARDING_KEY='motilyStudioOnboardingDismissedV1';
const onboardingSteps=[
  {title:'1. Kiểm tra máy trước',badge:'SETUP',html:`<div class="guide-step"><p>Motily là một studio chạy <b>trên máy của bạn</b>. Trước video đầu tiên, hãy chắc rằng runtime đã sẵn sàng.</p><div class="guide-callout"><b>Làm gì:</b><ol><li>Mở tab <b>Checks</b>.</li><li>Bấm <b>Run preflight</b>.</li><li>Nếu có dòng BLOCK, sửa dòng đó trước khi render.</li></ol></div><p class="guide-muted">Preflight kiểm tra Gemini, FFmpeg/FFprobe, visual provider, Tí, evidence và audio bindings. Nó không render video.</p></div>`},
  {title:'2. Tạo production đầu tiên',badge:'BRIEF',html:`<div class="guide-step"><p>Bấm <b>+ New production</b> ở thanh trái. Viết một brief ngắn về video bạn muốn làm.</p><div class="guide-example"><span>Ví dụ</span>“Vì sao cầu Tacoma Narrows rung dữ dội đến mức sập?”</div><div class="guide-callout"><b>Target nên chọn:</b> <b>Final video</b> nếu muốn pipeline đi xa nhất có thể.</div><p class="guide-muted">Motily sẽ tự chạy đến điểm cần bạn duyệt rồi dừng, chứ không tự vượt qua quyết định của bạn.</p></div>`},
  {title:'3. Duyệt rồi Continue',badge:'GATES',html:`<div class="guide-step"><p>Khi trạng thái là <b>WAITING APPROVAL</b>, pipeline đang chờ bạn.</p><div class="guide-flow"><span>Review approval</span><b>→</b><span>Approve / Reject</span><b>→</b><span>Continue</span></div><p>Nếu duyệt, bấm <b>Approve</b>, sau đó <b>Continue</b>. Nếu Reject, Motily giữ artifact lại và không tự viết lại.</p><p class="guide-muted">Các gate chính đi qua Idea → Research → Narrative → Packaging → Script → Final media.</p></div>`},
  {title:'4. Khi Motily cần media thật',badge:'MEDIA',html:`<div class="guide-step"><p>Không phải cảnh nào AI cũng nên tự bịa. Với evidence, nhạc và SFX, Motily có thể yêu cầu file thật.</p><div class="guide-callout"><b>Tab Media:</b><ul><li><b>Evidence</b>: upload ảnh/video đúng nguồn research.</li><li><b>Music</b>: chọn nhạc nền.</li><li><b>SFX</b>: nhập đúng reference rồi chọn file hiệu ứng.</li></ul></div><p>Sau khi bind media, quay lại <b>Checks</b> → chạy Preflight → <b>Continue</b>.</p></div>`},
  {title:'5. Video được tạo ra thế nào',badge:'PIPELINE',html:`<div class="guide-step"><p>Bạn không cần điều khiển từng module. Motily điều phối toàn bộ pipeline:</p><div class="guide-stack"><span>Idea + Research</span><span>Story + Script</span><span>Voice + Visual + Tí + Diagram</span><span>Timeline + Motion + Music/SFX</span><span>Subtitle + Encode</span><span>QC → Final approval</span></div><p class="guide-muted">Tab Run cho biết đang ở bước nào. “Technical node trace” chỉ cần mở khi debug.</p></div>`},
  {title:'6. Cập nhật bản dev',badge:'UPDATE',html:`<div class="guide-step"><p>Trong sidebar có <b>Development build</b>. Đây là updater để khỏi tải rồi chép code thủ công mỗi lần.</p><div class="guide-callout"><ol><li>Mở <b>Development build</b>.</li><li>Motily đã có sẵn public update channel; bình thường không cần cấu hình gì.</li><li>Bấm <b>Check update</b>.</li><li>Nếu có bản mới, bấm <b>Update & restart</b>.</li></ol></div><p class="guide-muted">Project data, data/, .git và virtual environment được bảo vệ khi update.</p></div>`},
  {title:'Xong — cách dùng hằng ngày',badge:'READY',html:`<div class="guide-step"><div class="guide-ready">Bạn chỉ cần nhớ 5 việc</div><div class="guide-stack numbered"><span><b>1</b> New production</span><span><b>2</b> Approve khi Motily hỏi</span><span><b>3</b> Thêm media nếu bị yêu cầu</span><span><b>4</b> Run preflight rồi Continue</span><span><b>5</b> Duyệt video cuối</span></div><p>Bất kỳ lúc nào quên, bấm <b>Guide</b> trên góc phải để mở lại hướng dẫn này.</p></div>`},
];
let onboardingIndex=0;
function renderOnboarding(){
  const step=onboardingSteps[onboardingIndex];
  $('onboardingTitle').textContent=step.title;
  $('onboardingBody').innerHTML=step.html;
  $('onboardingProgress').innerHTML=onboardingSteps.map((_,i)=>`<span class="${i===onboardingIndex?'active':i<onboardingIndex?'done':''}"></span>`).join('');
  $('onboardingBackBtn').disabled=onboardingIndex===0;
  $('onboardingNextBtn').textContent=onboardingIndex===onboardingSteps.length-1?'Bắt đầu dùng Motily':'Tiếp →';
}
function openOnboarding(reset=true){if(reset)onboardingIndex=0;renderOnboarding();$('onboardingModal').classList.remove('hidden')}
function closeOnboarding(){if($('dontShowOnboarding').checked)localStorage.setItem(ONBOARDING_KEY,'1');$('onboardingModal').classList.add('hidden')}
const state={projects:[],projectId:null,project:null,run:null,decision:null,updateFile:null,stagedUpdate:null,remoteUpdate:null,updateChannel:null};
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

async function api(url,opts={}){const r=await fetch(url,opts);let body=null;try{body=await r.json()}catch{}if(!r.ok)throw new Error(body?.detail||`${r.status} ${r.statusText}`);return body}
function toast(msg,error=false){const el=$('toast');el.textContent=msg;el.className='toast'+(error?' error':'');clearTimeout(el._t);el._t=setTimeout(()=>el.className='toast hidden',3800)}
function shortId(id){return id?id.slice(0,8):'—'}
function fmtTime(v){if(!v)return '—';try{return new Date(v).toLocaleString()}catch{return v}}

function showTab(name){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===name));document.querySelectorAll('.tab-panel').forEach(x=>x.classList.toggle('active',x.id===`tab-${name}`))}
document.querySelectorAll('.tab').forEach(x=>x.addEventListener('click',()=>showTab(x.dataset.tab)));
document.querySelectorAll('[data-close]').forEach(x=>x.addEventListener('click',()=>$(x.dataset.close).classList.add('hidden')));

async function loadProjects(){
  state.projects=await api('/api/projects');
  const list=$('projectList');
  if(!state.projects.length){list.innerHTML='<div class="empty">No projects yet.</div>';return}
  list.innerHTML=state.projects.map(p=>`<div class="project-item ${p.project_id===state.projectId?'active':''}" data-project="${p.project_id}"><div class="project-title">${esc(p.title)}</div><div class="project-meta"><span>${esc(p.state)}</span><span><i class="status-dot ${(p.latest_run_status||'').toLowerCase()}"></i>${esc(p.latest_run_status||'no run')}</span></div></div>`).join('');
  list.querySelectorAll('[data-project]').forEach(el=>el.addEventListener('click',()=>selectProject(el.dataset.project)));
}

async function selectProject(id){
  state.projectId=id;await loadProjects();await refreshProject();
}

async function refreshProject(){
  if(!state.projectId)return;
  const data=await api(`/api/projects/${state.projectId}`);state.project=data.project;state.run=data.runs[0]||null;
  renderProject(data);await Promise.all([loadEvidence(),loadAudio()]);
}

function renderProject(data){
  $('projectTitle').textContent=data.project.title;
  $('metricState').textContent=data.project.state;
  $('metricRun').textContent=state.run?shortId(state.run.run_id):'No run';
  $('metricExecuted').textContent=state.run?.executed_count??0;$('metricReused').textContent=state.run?.reused_count??0;
  $('runPreflightBtn').disabled=false;
  renderRun(state.run);
  $('runHistory').innerHTML=data.runs.length?data.runs.map(r=>`<div class="run-card" data-run="${r.run_id}"><div class="run-card-top"><strong>${esc(r.status)}</strong><span class="run-id">${shortId(r.run_id)}</span></div><div class="project-meta"><span>${esc(r.target_node)}</span><span>${fmtTime(r.updated_at)}</span></div></div>`).join(''):'<div class="empty">No runs.</div>';
  $('runHistory').querySelectorAll('[data-run]').forEach(el=>el.addEventListener('click',async()=>{state.run=await api(`/api/runs/${el.dataset.run}`);renderRun(state.run);showTab('production')}));
}

const workflowGroups=[
  ['Idea',['IDEA']],
  ['Research',['RESEARCH_R0','FEASIBILITY','RESEARCH_R1']],
  ['Story',['NARRATIVE','PACKAGING_P0','SCRIPT','SCRIPT_VERIFY']],
  ['Plans',['VOICE_PLAN','VISUAL_PLAN','ASSEMBLY_PLAN','PACKAGING_P1']],
  ['Render',['VOICE_RENDER','VISUAL_RENDER','TIMELINE','VIDEO_RENDER','CAPTION_BUILD','SUBTITLE_EXPORT']],
  ['QC',['MEDIA_QC']],
];
function workflowStage(nodes,ids){
  const selected=nodes.filter(n=>ids.includes(n.node_id));
  if(!selected.length)return ['idle','Not started'];
  if(selected.some(n=>n.status==='FAILED'||n.status==='BLOCKED'))return ['problem','Needs attention'];
  if(selected.some(n=>n.status==='WAITING_APPROVAL'))return ['waiting','Waiting approval'];
  if(selected.every(n=>n.status==='SUCCEEDED'))return ['done','Complete'];
  return ['active','In progress'];
}
function configurePrimaryAction(run){
  const btn=$('primaryActionBtn');
  btn.onclick=null;
  if(!run){btn.textContent='New production';btn.disabled=false;btn.onclick=()=>$('newProjectModal').classList.remove('hidden');return}
  if(run.status==='WAITING_APPROVAL'){btn.textContent='Review approval';btn.disabled=false;btn.onclick=()=>openDecision('approve');return}
  if(run.status==='SUCCEEDED'){btn.textContent='Complete';btn.disabled=true;return}
  btn.textContent='Continue';btn.disabled=false;btn.onclick=resumeCurrent;
}
function renderRun(run){
  const waiting=run?.status==='WAITING_APPROVAL';
  $('approveBtn').disabled=!waiting;$('rejectBtn').disabled=!waiting;configurePrimaryAction(run);
  if(!run){
    $('heroStatus').textContent='Project ready';$('heroCopy').textContent='Start a production run from this project.';$('heroBadge').textContent='IDLE';$('pipelineChip').textContent='No run';$('pipelineOverview').innerHTML='<div class="empty">No production run yet.</div>';$('nodeTableBody').innerHTML='<tr><td colspan="5" class="empty-cell">No run selected.</td></tr>';$('workflowStrip').innerHTML='';$('pipelineProgress').style.width='0%';$('pipelineProgressText').textContent='0 of 19 steps completed';$('nextAction').innerHTML='<div class="action-callout"><strong>Start a new run</strong><p>Create a production from a brief. Motily will stop only when it needs your decision or an input asset.</p></div>';return
  }
  $('heroStatus').textContent=run.status.replaceAll('_',' ');$('heroBadge').textContent=run.waiting_gate?run.waiting_gate.replace('_APPROVAL',''):run.target_node;$('pipelineChip').textContent=shortId(run.run_id);
  const copy={SUCCEEDED:'Final target completed.',WAITING_APPROVAL:`Waiting for ${run.waiting_gate}.`,BLOCKED:`Blocked: ${run.stop_reason||'domain condition'}.`,FAILED:`A production node failed. Open the technical trace if you need debugging detail.`,RUNNING:'Production is currently running.'};$('heroCopy').textContent=copy[run.status]||run.status;
  const nodes=run.nodes||[];
  const completed=nodes.filter(n=>n.status==='SUCCEEDED').length;const total=Math.max(19,nodes.length||0);const pct=Math.min(100,Math.round(completed/total*100));$('pipelineProgress').style.width=`${pct}%`;$('pipelineProgressText').textContent=`${completed} of ${total} steps completed`;
  $('pipelineOverview').innerHTML=nodes.length?nodes.slice(-8).map(n=>`<div class="pipe-row ${n.status}"><span class="pipe-state"></span><span class="pipe-name">${esc(n.node_id)}</span><span class="pipe-mode">${n.executed?'executed':n.reused?'reused':n.status}</span></div>`).join(''):'<div class="empty">No node trace.</div>';
  $('workflowStrip').innerHTML=workflowGroups.map(([label,ids])=>{const [cls,text]=workflowStage(nodes,ids);return `<div class="workflow-stage ${cls}"><strong>${label}</strong><span>${text}</span></div>`}).join('');
  $('nodeTableBody').innerHTML=nodes.length?nodes.map(n=>`<tr><td><strong>${esc(n.node_id)}</strong></td><td class="node-status ${n.status}">${esc(n.status)}</td><td>${n.executed?'executed':n.reused?'reused':'—'}</td><td>${esc(n.reason||'—')}</td><td class="mono">${esc(shortId(n.artifact_id))}</td></tr>`).join(''):'<tr><td colspan="5" class="empty-cell">No nodes.</td></tr>';
  $('runMeta').innerHTML=`<span>Run <b class="mono">${esc(shortId(run.run_id))}</b></span><span>Target <b>${esc(run.target_node)}</b></span><span>Updated <b>${fmtTime(run.updated_at)}</b></span>`;
  if(waiting){$('nextAction').innerHTML=`<div class="action-callout"><strong>Your decision is needed</strong><p>${esc(run.waiting_gate)} is the only thing stopping the next stage.</p><div class="action-buttons"><button class="btn primary" id="nextApprove">Review & approve</button><button class="btn danger-ghost" id="nextReject">Reject</button></div></div>`;setTimeout(()=>{$('nextApprove')?.addEventListener('click',()=>openDecision('approve'));$('nextReject')?.addEventListener('click',()=>openDecision('reject'))},0)}else if(run.status==='SUCCEEDED'){$('nextAction').innerHTML='<div class="action-callout"><strong>Production complete</strong><p>The requested target is complete. No further pipeline action is required.</p></div>'}else{$('nextAction').innerHTML=`<div class="action-callout"><strong>${esc(run.status)}</strong><p>${esc(run.stop_reason||'Continue when the underlying condition is ready.')}</p><div class="action-buttons"><button class="btn primary" id="nextResume">Continue production</button></div></div>`;setTimeout(()=>$('nextResume')?.addEventListener('click',resumeCurrent),0)}
}

async function loadEvidence(){if(!state.projectId)return;try{const rows=await api(`/api/projects/${state.projectId}/evidence`);const box=$('evidenceList');if(!rows.length){box.innerHTML='<div class="empty">No current ResearchPackage sources yet.</div>';return}box.innerHTML=rows.map(r=>`<div class="evidence-row"><div><div class="evidence-title">${esc(r.title)}</div><div class="evidence-meta">${esc(r.source_id)} · beats ${esc((r.beat_ids||[]).join(', ')||'—')}</div>${!r.bound?`<div class="evidence-upload"><label class="upload-box compact"><span>Bind media</span><input type="file" data-evidence="${esc(r.source_id)}" accept="image/*,video/*"/></label></div>`:''}</div><span class="binding-badge ${r.bound?'bound':'unbound'}">${r.bound?'BOUND':'UNBOUND'}</span></div>`).join('');box.querySelectorAll('[data-evidence]').forEach(inp=>inp.addEventListener('change',()=>bindEvidence(inp.dataset.evidence,inp.files[0])))}catch(e){$('evidenceList').innerHTML=`<div class="empty">${esc(e.message)}</div>`}}

async function bindEvidence(sourceId,file){if(!file)return;const fd=new FormData();fd.append('source_id',sourceId);fd.append('file',file);try{await api(`/api/projects/${state.projectId}/evidence/bind`,{method:'POST',body:fd});toast(`Evidence bound to ${sourceId}`);await loadEvidence();await runPreflight()}catch(e){toast(e.message,true)}}

async function loadAudio(){if(!state.projectId)return;const a=await api(`/api/projects/${state.projectId}/audio`);$('audioStatus').innerHTML=`<div class="audio-line"><span>Mode</span><strong>${a.enabled?'Production audio':'Narration only'}</strong></div><div class="audio-line"><span>Music</span><strong>${a.music_bed_path?esc(a.music_bed_path.split(/[\\/]/).pop()):'—'}</strong></div><div class="audio-line"><span>SFX</span><strong>${esc((a.sfx_references||[]).join(', ')||'—')}</strong></div>${a.error?`<div class="audio-line"><span>Error</span><strong style="color:var(--bad)">${esc(a.error)}</strong></div>`:''}`}

async function uploadAudio(kind,file,reference){if(!state.projectId||!file)return;const fd=new FormData();fd.append('file',file);if(reference)fd.append('reference',reference);try{await api(`/api/projects/${state.projectId}/audio/${kind}`,{method:'POST',body:fd});toast(kind==='music'?'Music bed bound':`SFX ${reference} bound`);await loadAudio();await runPreflight()}catch(e){toast(e.message,true)}}
$('musicFile').addEventListener('change',e=>uploadAudio('music',e.target.files[0]));$('sfxFile').addEventListener('change',e=>{const ref=$('sfxReference').value.trim();if(!ref){toast('Enter an exact SFX reference first.',true);e.target.value='';return}uploadAudio('sfx',e.target.files[0],ref)});

async function runPreflight(){if(!state.projectId)return;try{const r=await api(`/api/projects/${state.projectId}/readiness`);$('preflightSummary').innerHTML=`Overall readiness: <span class="check-status ${r.overall_status}">${esc(r.overall_status)}</span>`;$('preflightChecks').innerHTML=(r.checks||[]).map(c=>`<div class="check-row"><span class="check-status ${c.status}">${esc(c.status)}</span><strong>${esc(c.check_id)}</strong><span>${esc(c.message)}</span></div>`).join('');toast(`Preflight: ${r.overall_status}`)}catch(e){toast(e.message,true)}}
$('runPreflightBtn').addEventListener('click',runPreflight);

async function resumeCurrent(){if(!state.run)return;try{const r=await api(`/api/runs/${state.run.run_id}/resume`,{method:'POST'});state.run=r.run;toast(r.message);await refreshProject()}catch(e){toast(e.message,true)}}


function openDecision(kind){if(!state.run)return;state.decision=kind;$('decisionEyebrow').textContent=kind==='approve'?'Approval':'Rejection';$('decisionTitle').textContent=`${kind==='approve'?'Approve':'Reject'} ${state.run.waiting_gate||'gate'}`;$('confirmDecisionBtn').className=`btn ${kind==='approve'?'primary':'danger-ghost'}`;$('decisionNote').value='';$('decisionModal').classList.remove('hidden')}
$('approveBtn').addEventListener('click',()=>openDecision('approve'));$('rejectBtn').addEventListener('click',()=>openDecision('reject'));
$('confirmDecisionBtn').addEventListener('click',async()=>{try{const body={note:$('decisionNote').value||null};const r=await api(`/api/runs/${state.run.run_id}/${state.decision}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});toast(r.message);$('decisionModal').classList.add('hidden');await refreshProject()}catch(e){toast(e.message,true)}});

$('newProjectBtn').addEventListener('click',()=>{$('newProjectModal').classList.remove('hidden');$('briefInput').focus()});
$('newProjectForm').addEventListener('submit',async e=>{e.preventDefault();const body={brief:$('briefInput').value.trim(),domain:$('domainInput').value.trim()||'physics',target:$('targetInput').value,additional_context:$('contextInput').value.trim()||null};if(!body.brief)return;try{const r=await api('/api/productions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});state.run=r.run;state.projectId=r.run.project_id;$('newProjectModal').classList.add('hidden');toast(r.message);await loadProjects();await refreshProject()}catch(err){toast(err.message,true)}});
$('refreshBtn').addEventListener('click',async()=>{await loadProjects();if(state.projectId)await refreshProject();toast('Refreshed')});

async function loadUpdateStatus(){
  try{
    const s=await api('/api/dev-update/status');
    state.updateChannel=s.remote_channel||null;
    $('versionText').textContent=`v${s.current_version} · ${s.current_build_id||'dev'} · update`;
    $('updateCurrentVersion').textContent=`v${s.current_version} · ${s.current_build_id||'dev'}`;
    state.stagedUpdate=s.staged||null;
    $('updateStagedVersion').textContent=s.staged?`v${s.staged.version} · ${s.staged.build_id||'dev'}`:'None';
    $('applyUpdateBtn').disabled=!s.staged;
    const configured=!!(s.remote_channel&&s.remote_channel.configured);
    $('checkUpdateBtn').disabled=!configured;
    $('quickUpdateBtn').disabled=true;
    $('updateChannelText').textContent=configured?`${s.remote_channel.repository} · ${s.remote_channel.branch}`:'Public dev channel';
    $('updateRepoInput').value=configured?(s.remote_channel.repository||''):'';
    $('updateBranchInput').value=configured?(s.remote_channel.branch||'main'):'main';
    $('updateRemoteStatus').textContent=configured?'Ready to check the development branch.':'Public dev channel is ready. Just check for updates.';
    $('updateRemoteVersion').textContent='Not checked';
  }catch(e){
    $('versionText').textContent='Updater unavailable';
    $('updateChannelText').textContent='Unavailable';
    $('updateRemoteStatus').textContent=e.message;
  }
}
async function checkRemoteUpdate(showToast=true){
  if(!state.updateChannel||!state.updateChannel.configured)return null;
  $('checkUpdateBtn').disabled=true;
  $('updateProgress').classList.remove('hidden');
  try{
    const r=await api('/api/dev-update/check',{method:'POST'});
    state.remoteUpdate=r.remote;
    $('updateRemoteVersion').textContent=r.remote.short_revision;
    if(r.remote.available){
      $('updateRemoteStatus').textContent=`New build ${r.remote.short_revision} is available${r.remote.committed_at?` · ${fmtTime(r.remote.committed_at)}`:''}.`;
      $('quickUpdateBtn').disabled=false;
      $('versionText').textContent=`Update available · ${r.remote.short_revision}`;
      if(showToast)toast('Development update available');
    }else{
      $('updateRemoteStatus').textContent=`Up to date at ${r.remote.short_revision}.`;
      $('quickUpdateBtn').disabled=true;
      if(showToast)toast('Motily is up to date');
    }
    return r.remote;
  }catch(e){
    $('updateRemoteStatus').textContent=e.message;
    $('quickUpdateBtn').disabled=true;
    if(showToast)toast(e.message,true);
    return null;
  }finally{
    $('checkUpdateBtn').disabled=!(state.updateChannel&&state.updateChannel.configured);
    $('updateProgress').classList.add('hidden');
  }
}
function openUpdate(){
  state.updateFile=null;
  state.remoteUpdate=null;
  $('updateFile').value='';
  $('updateFileInfo').classList.add('hidden');
  $('stageUpdateBtn').disabled=true;
  $('updateProgress').classList.add('hidden');
  $('updateModal').classList.remove('hidden');
  loadUpdateStatus().then(()=>{if(state.updateChannel&&state.updateChannel.configured)checkRemoteUpdate(false)});
}
$('openUpdateBtn').addEventListener('click',openUpdate);
$('saveUpdateChannelBtn').addEventListener('click',async()=>{
  const repository=$('updateRepoInput').value.trim();
  const branch=$('updateBranchInput').value.trim()||'main';
  if(!repository){toast('Enter a GitHub repository as owner/repository.',true);return}
  $('saveUpdateChannelBtn').disabled=true;
  try{
    const r=await api('/api/dev-update/configure',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({repository,branch})});
    state.updateChannel=r.remote_channel;
    $('updateChannelText').textContent=`${r.remote_channel.repository} · ${r.remote_channel.branch}`;
    $('updateRemoteStatus').textContent='Update channel saved. Checking now…';
    $('checkUpdateBtn').disabled=false;
    toast('Update channel saved');
    await checkRemoteUpdate(false);
  }catch(e){toast(e.message,true)}finally{$('saveUpdateChannelBtn').disabled=false}
});
$('checkUpdateBtn').addEventListener('click',()=>checkRemoteUpdate(true));
function chooseUpdateFile(file){if(!file)return;if(!file.name.toLowerCase().endsWith('.zip')){toast('Choose a Motily .zip development build.',true);return}state.updateFile=file;$('updateFileInfo').classList.remove('hidden');$('updateFileInfo').innerHTML=`<span>${esc(file.name)}</span><strong>${(file.size/1024/1024).toFixed(1)} MB</strong>`;$('stageUpdateBtn').disabled=false}
$('updateFile').addEventListener('change',e=>chooseUpdateFile(e.target.files[0]));
const drop=$('updateDrop');['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('drag')}));['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('drag')}));drop.addEventListener('drop',e=>chooseUpdateFile(e.dataTransfer.files[0]));
$('stageUpdateBtn').addEventListener('click',async()=>{if(!state.updateFile)return;const fd=new FormData();fd.append('file',state.updateFile);$('updateProgress').classList.remove('hidden');$('stageUpdateBtn').disabled=true;try{const r=await api('/api/dev-update/stage',{method:'POST',body:fd});state.stagedUpdate=r.staged;$('updateStagedVersion').textContent=`v${r.staged.version} · ${r.staged.build_id||'dev'}`;$('applyUpdateBtn').disabled=false;toast('Update validated and staged')}catch(e){toast(e.message,true);$('stageUpdateBtn').disabled=false}finally{$('updateProgress').classList.add('hidden')}});
$('applyUpdateBtn').addEventListener('click',async()=>{if(!state.stagedUpdate)return;$('applyUpdateBtn').disabled=true;$('updateProgress').classList.remove('hidden');try{await api(`/api/dev-update/apply/${state.stagedUpdate.update_id}`,{method:'POST'});$('updateModal').classList.add('hidden');$('restartModal').classList.remove('hidden')}catch(e){toast(e.message,true);$('applyUpdateBtn').disabled=false}finally{$('updateProgress').classList.add('hidden')}});
async function requestStudioRestart(){
  await api('/api/dev-update/restart',{method:'POST'});
  $('restartStudioBtn').disabled=true;
  $('restartStudioBtn').textContent='Restarting…';
  toast('Restarting Studio…');
  const started=Date.now();
  const poll=async()=>{if(Date.now()-started>30000){location.reload();return}try{await fetch('/api/health',{cache:'no-store'});location.reload()}catch{setTimeout(poll,700)}};
  setTimeout(poll,1200);
}
$('quickUpdateBtn').addEventListener('click',async()=>{
  $('quickUpdateBtn').disabled=true;
  $('checkUpdateBtn').disabled=true;
  $('updateProgress').classList.remove('hidden');
  $('updateRemoteStatus').textContent='Downloading, validating and installing the new build…';
  try{
    const r=await api('/api/dev-update/quick',{method:'POST'});
    if(!r.updated){
      $('updateRemoteStatus').textContent='Already up to date.';
      toast('Motily is up to date');
      return;
    }
    $('updateRemoteStatus').textContent='Installed. Restarting Studio…';
    $('updateModal').classList.add('hidden');
    try{await requestStudioRestart()}catch(e){$('restartModal').classList.remove('hidden');toast(`${e.message}. Restart Studio manually.`,true)}
  }catch(e){
    $('updateRemoteStatus').textContent=e.message;
    toast(e.message,true);
    $('quickUpdateBtn').disabled=false;
    $('checkUpdateBtn').disabled=false;
  }finally{
    $('updateProgress').classList.add('hidden');
  }
});
$('manualRestartBtn').addEventListener('click',()=>{$('restartModal').classList.add('hidden');toast('Restart Motily Studio when convenient.')});
$('restartStudioBtn').addEventListener('click',async()=>{try{await requestStudioRestart()}catch(e){toast(`${e.message}. Restart Studio manually.`,true)}});

$('helpBtn').addEventListener('click',()=>openOnboarding(true));
$('closeOnboardingBtn').addEventListener('click',closeOnboarding);
$('onboardingBackBtn').addEventListener('click',()=>{if(onboardingIndex>0){onboardingIndex--;renderOnboarding()}});
$('onboardingNextBtn').addEventListener('click',()=>{if(onboardingIndex<onboardingSteps.length-1){onboardingIndex++;renderOnboarding()}else{closeOnboarding();$('newProjectModal').classList.remove('hidden');$('briefInput').focus()}});

async function boot(){try{await api('/api/health');await loadUpdateStatus();await loadProjects();if(state.projects.length){await selectProject(state.projects[0].project_id)}if(!localStorage.getItem(ONBOARDING_KEY))setTimeout(()=>openOnboarding(true),250)}catch(e){$('healthPill').innerHTML='<span class="dot" style="background:var(--bad)"></span> Studio error';toast(e.message,true)}}
boot();
