"""Provider-independent hero-video generation interface."""

from typing import Protocol, runtime_checkable

from app.hero_video.models import HeroVideoRenderRequest, HeroVideoRenderResponse


@runtime_checkable
class HeroVideoProvider(Protocol):
    def render(self, request: HeroVideoRenderRequest) -> HeroVideoRenderResponse:
        ...
