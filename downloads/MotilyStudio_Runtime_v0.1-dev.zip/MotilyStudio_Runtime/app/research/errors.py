"""Research-retrieval-layer errors."""

from __future__ import annotations


class ResearchRetrieverError(Exception):
    """Base error for research retrieval failures."""


class ResearchRetrieverConfigurationError(ResearchRetrieverError):
    """Retriever configuration is missing or invalid."""


class ResearchRetrieverAuthenticationError(ResearchRetrieverError):
    """Search provider rejected authentication/authorization."""


class ResearchRetrieverRateLimitError(ResearchRetrieverError):
    """Search provider rate limit was reached."""


class ResearchRetrieverTimeoutError(ResearchRetrieverError):
    """Search provider timed out."""


class ResearchRetrieverTransportError(ResearchRetrieverError):
    """Network transport failed before a usable response arrived."""


class ResearchRetrieverResponseError(ResearchRetrieverError):
    """Provider returned a response that could not satisfy the retrieval contract."""
