"""Concrete research-retrieval providers.

The research engines continue to depend only on ``ResearchRetriever``. Provider
selection belongs in the application composition root, not in the engines or
orchestration core.
"""

from app.research.providers.gemini import (
    DEFAULT_GEMINI_SEARCH_MODEL,
    GeminiSearchConfig,
    GeminiSearchRetriever,
)

__all__ = [
    "DEFAULT_GEMINI_SEARCH_MODEL",
    "GeminiSearchConfig",
    "GeminiSearchRetriever",
]
