from __future__ import annotations

from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.production_audio.service import (
    bind_local_music_bed,
    bind_local_sfx,
    resolve_audio_asset_bindings,
)
from app.workspace.storage import WorkspaceBlobStore


class ProductionAudioService:
    """Thin application façade for explicit production music/SFX binding."""

    def __init__(self, engine: Engine, blob_store: WorkspaceBlobStore):
        self._engine = engine
        self._blob_store = blob_store

    def bind_music(self, project_id: UUID, source_path: Path | str):
        return bind_local_music_bed(
            self._engine, self._blob_store, project_id=project_id, source_path=source_path
        )

    def bind_sfx(self, project_id: UUID, reference: str, source_path: Path | str):
        return bind_local_sfx(
            self._engine, self._blob_store,
            project_id=project_id, reference=reference, source_path=source_path,
        )

    def resolve(self, project_id: UUID):
        return resolve_audio_asset_bindings(
            self._engine, self._blob_store, project_id=project_id
        )
