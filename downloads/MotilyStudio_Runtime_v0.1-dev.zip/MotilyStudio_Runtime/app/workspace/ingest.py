"""Deterministic local workspace-file ingestion.

This module intentionally performs no semantic classification.  The caller
supplies the WorkspaceAssetType; we validate the file, hash its exact bytes,
write one content-addressed blob, and persist immutable metadata.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.storage.workspace_assets import find_assets_by_sha256, save_workspace_asset
from app.workspace.classification import classify_extension, extension_of, validate_content
from app.workspace.errors import WorkspaceFileEmptyError, WorkspaceFileMissingError
from app.workspace.models import AssetOrigin, WorkspaceAsset, WorkspaceAssetType
from app.workspace.storage import WorkspaceBlobStore, blob_relative_path


def ingest_workspace_file(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
    source_path: Path | str,
    asset_type: WorkspaceAssetType,
    origin: AssetOrigin = AssetOrigin.USER_PROVIDED,
    logical_name: str | None = None,
    note: str | None = None,
    tags: list[str] | None = None,
) -> WorkspaceAsset:
    path = Path(source_path)
    if not path.is_file():
        raise WorkspaceFileMissingError(f"Workspace source file does not exist: {path}")
    size = path.stat().st_size
    if size <= 0:
        raise WorkspaceFileEmptyError(f"Workspace source file is empty: {path}")

    extension = extension_of(path)
    category = classify_extension(extension)
    validate_content(path, category, extension)
    data = path.read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()

    # Exact logical duplicates reuse the existing immutable row as well as the
    # physical blob.  Different roles/logical names may legitimately point at
    # the same content-addressed bytes.
    for existing in find_assets_by_sha256(engine, project_id, sha256):
        if (
            existing.asset_type is asset_type
            and existing.origin is origin
            and existing.logical_name == logical_name
        ):
            return existing

    relative_path = blob_relative_path(project_id, sha256, extension)
    blob_store.write_if_absent(relative_path, data)
    asset = WorkspaceAsset(
        project_id=project_id,
        asset_type=asset_type,
        origin=origin,
        original_filename=path.name,
        stored_relative_path=relative_path,
        media_type=extension,
        file_size_bytes=size,
        sha256=sha256,
        created_at=datetime.now(timezone.utc),
        note=note,
        tags=list(tags or []),
        logical_name=logical_name,
    )
    save_workspace_asset(engine, asset)
    return asset
