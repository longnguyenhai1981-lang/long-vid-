from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.evidence_media.service import bind_local_evidence_media, evidence_selection_role
from app.engines.research_r1.models import RESEARCH_R1_ARTIFACT_TYPE
from app.models.research import ResearchPackage
from app.models.visual import VisualPlan
from app.engines.visual_plan.models import VISUAL_PLAN_ARTIFACT_TYPE
from app.storage.artifacts import get_artifact
from app.storage.errors import ArtifactNotFoundError
from app.storage.workspace_assets import get_workspace_asset, get_workspace_asset_selection
from app.workspace.storage import WorkspaceBlobStore


@dataclass(frozen=True)
class EvidenceBindingStatus:
    source_id: str
    title: str
    bound: bool
    beat_ids: tuple[str, ...]
    file_path: str | None = None
    workspace_asset_id: str | None = None


class EvidenceMediaService:
    def __init__(self, db_engine: Engine, blob_store: WorkspaceBlobStore):
        self._db_engine = db_engine
        self._blob_store = blob_store

    def bind(self, project_id: UUID, source_id: str, source_path: Path | str):
        return bind_local_evidence_media(
            self._db_engine,
            self._blob_store,
            project_id=project_id,
            source_id=source_id,
            source_path=source_path,
        )

    def status(self, project_id: UUID) -> list[EvidenceBindingStatus]:
        try:
            research = get_artifact(
                self._db_engine, project_id, RESEARCH_R1_ARTIFACT_TYPE, ResearchPackage
            )
        except ArtifactNotFoundError:
            return []

        bound_by_source: dict[str, tuple[str, str]] = {}
        for source in research.sources:
            selection = get_workspace_asset_selection(
                self._db_engine, project_id, evidence_selection_role(source.source_id)
            )
            if selection is None:
                continue
            asset = get_workspace_asset(self._db_engine, selection.asset_id)
            path = self._blob_store.resolve(asset.stored_relative_path)
            bound_by_source[source.source_id] = (str(path), str(asset.id))


        beat_ids_by_source: dict[str, list[str]] = {}
        try:
            visual_plan = get_artifact(
                self._db_engine, project_id, VISUAL_PLAN_ARTIFACT_TYPE, VisualPlan
            )
        except ArtifactNotFoundError:
            visual_plan = None
        if visual_plan is not None:
            for beat in visual_plan.beats:
                for source_id in beat.evidence_source_ids:
                    beat_ids_by_source.setdefault(source_id, []).append(beat.beat_id)

        result: list[EvidenceBindingStatus] = []
        for source in research.sources:
            bound = bound_by_source.get(source.source_id)
            result.append(
                EvidenceBindingStatus(
                    source_id=source.source_id,
                    title=source.title,
                    bound=bound is not None,
                    beat_ids=tuple(sorted(beat_ids_by_source.get(source.source_id, []))),
                    file_path=bound[0] if bound else None,
                    workspace_asset_id=bound[1] if bound else None,
                )
            )
        return result
