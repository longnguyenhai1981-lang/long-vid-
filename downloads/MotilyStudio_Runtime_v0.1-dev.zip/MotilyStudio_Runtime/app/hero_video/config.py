"""Execution settings for hero-video generation."""

from pydantic import model_validator

from app.models.common import MotilyModel, non_blank


class HeroVideoSettings(MotilyModel):
    provider: str
    max_provider_retries: int = 0
    aspect_ratio: str = "16:9"
    resolution: str = "720p"

    @model_validator(mode="after")
    def _check_invariants(self) -> "HeroVideoSettings":
        non_blank(self.provider, "provider")
        if self.max_provider_retries < 0:
            raise ValueError("max_provider_retries must be >= 0")
        if self.aspect_ratio not in {"16:9", "9:16"}:
            raise ValueError("aspect_ratio must be '16:9' or '9:16'")
        if self.resolution not in {"720p", "1080p", "4k"}:
            raise ValueError("resolution must be one of '720p', '1080p', '4k'")
        return self
