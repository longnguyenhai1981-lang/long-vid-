"""Hero-video provider domain errors."""

class HeroVideoError(Exception):
    """Base class for AI hero-video generation errors."""


class HeroVideoProviderError(HeroVideoError):
    """Transient provider/network failure; renderer may retry."""


class HeroVideoOutputError(HeroVideoError):
    """Provider returned no usable video bytes/metadata; never retried."""


class HeroVideoConfigurationError(HeroVideoError):
    """Provider cannot be configured (for example, missing API key)."""
