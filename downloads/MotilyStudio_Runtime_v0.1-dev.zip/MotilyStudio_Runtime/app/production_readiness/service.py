"""Deterministic, no-network production-readiness inspection.

This module does not execute production nodes and does not call any provider.
It only inspects current artifacts, local bindings, local tools, and configured
credential presence so an operator can see what would block a final run before
paying for or starting media generation.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.evidence_media.service import resolve_evidence_media_sources
from app.engines.visual_plan.models import VISUAL_PLAN_ARTIFACT_TYPE
from app.models.common import VisualMediaType
from app.models.visual import VisualPlan
from app.production_audio.errors import ProductionAudioError
from app.production_audio.service import resolve_audio_asset_bindings
from app.production_readiness.models import ProductionReadinessReport, ReadinessCheck, ReadinessStatus
from app.renderers.visual.errors import AmbiguousAssetReuseKeyError
from app.renderers.visual.reuse import derive_asset_reuse_sources
from app.storage.artifacts import get_artifact
from app.storage.errors import ArtifactNotFoundError, TiAssetSetNotFoundError
from app.storage.ti_assets import get_active_ti_asset_set
from app.workspace.storage import DEFAULT_WORKSPACE_ROOT, WorkspaceBlobStore


def _check(check_id: str, status: ReadinessStatus, message: str, **details: object) -> ReadinessCheck:
    return ReadinessCheck(check_id=check_id, status=status, message=message, details=details)


def inspect_production_readiness(
    engine: Engine,
    project_id: UUID,
    *,
    workspace_root: Path | str | None = None,
    environ: dict[str, str] | None = None,
) -> ProductionReadinessReport:
    env = os.environ if environ is None else environ
    checks: list[ReadinessCheck] = []

    # Core runtime tooling.
    for executable in ("ffmpeg", "ffprobe"):
        path = shutil.which(executable)
        checks.append(
            _check(
                f"RUNTIME_{executable.upper()}",
                ReadinessStatus.PASS if path else ReadinessStatus.BLOCK,
                f"{executable} is available" if path else f"{executable} is not available on PATH",
                path=path,
            )
        )

    # Upstream production runtime. One Gemini key is currently shared by LLM,
    # search grounding and TTS. Presence only; no network verification here.
    gemini_present = bool(env.get("GEMINI_API_KEY", "").strip())
    checks.append(
        _check(
            "RUNTIME_GEMINI_KEY",
            ReadinessStatus.PASS if gemini_present else ReadinessStatus.BLOCK,
            "Gemini credential is configured" if gemini_present else "GEMINI_API_KEY is missing (LLM/research/TTS cannot run)",
        )
    )

    # Current VisualPlan may not exist yet. That is not itself an environment
    # failure; preflight can still report upstream/runtime readiness.
    try:
        visual_plan = get_artifact(engine, project_id, VISUAL_PLAN_ARTIFACT_TYPE, VisualPlan)
    except ArtifactNotFoundError:
        visual_plan = None
        checks.append(
            _check(
                "VISUAL_PLAN",
                ReadinessStatus.WARN,
                "No current VisualPlan yet; media-specific readiness cannot be fully evaluated",
            )
        )

    if visual_plan is not None:
        media_types = {beat.media_type for beat in visual_plan.beats}

        # Still-image provider is needed only if the current plan contains beats
        # that actually call it.
        requires_still_provider = bool(
            media_types & {VisualMediaType.GENERATED_STILL, VisualMediaType.LIMITED_MOTION}
        )
        if requires_still_provider:
            visual_provider = env.get("MOTILY_VISUAL_PROVIDER", "cloudflare").strip().lower()
            if visual_provider == "cloudflare":
                ready = bool(env.get("CLOUDFLARE_ACCOUNT_ID", "").strip()) and bool(
                    env.get("CLOUDFLARE_API_TOKEN", "").strip()
                )
                checks.append(
                    _check(
                        "VISUAL_PROVIDER",
                        ReadinessStatus.PASS if ready else ReadinessStatus.BLOCK,
                        "Cloudflare visual provider is configured"
                        if ready
                        else "Current VisualPlan needs generated stills but Cloudflare credentials are incomplete",
                        provider="cloudflare",
                    )
                )
            elif visual_provider == "gemini":
                checks.append(
                    _check(
                        "VISUAL_PROVIDER",
                        ReadinessStatus.PASS if gemini_present else ReadinessStatus.BLOCK,
                        "Gemini visual provider is configured"
                        if gemini_present
                        else "Current VisualPlan needs generated stills but GEMINI_API_KEY is missing",
                        provider="gemini",
                    )
                )
            else:
                checks.append(
                    _check(
                        "VISUAL_PROVIDER",
                        ReadinessStatus.BLOCK,
                        f"Unsupported MOTILY_VISUAL_PROVIDER={visual_provider!r}",
                        provider=visual_provider,
                    )
                )

        if VisualMediaType.TI_STATE in media_types:
            try:
                asset_set = get_active_ti_asset_set(engine)
            except TiAssetSetNotFoundError:
                checks.append(
                    _check(
                        "TI_CANONICAL_ASSETS",
                        ReadinessStatus.BLOCK,
                        "VisualPlan uses Tí but no active canonical TiAssetSet is registered",
                    )
                )
            else:
                checks.append(
                    _check(
                        "TI_CANONICAL_ASSETS",
                        ReadinessStatus.PASS,
                        "Canonical Tí asset set is active",
                        asset_set_id=str(asset_set.id),
                        version=asset_set.version,
                    )
                )

        # Evidence is never fabricated. Every evidence beat must have an exact
        # local binding before a final media run is truly ready.
        evidence_beats = [b for b in visual_plan.beats if b.media_type is VisualMediaType.EVIDENCE_MEDIA]
        if evidence_beats:
            root = Path(env.get("MOTILY_WORKSPACE_ROOT", str(workspace_root or DEFAULT_WORKSPACE_ROOT)))
            resolved, _fingerprint = resolve_evidence_media_sources(
                engine, WorkspaceBlobStore(root), project_id=project_id
            )
            missing = [b.beat_id for b in evidence_beats if b.beat_id not in resolved]
            checks.append(
                _check(
                    "EVIDENCE_BINDINGS",
                    ReadinessStatus.BLOCK if missing else ReadinessStatus.PASS,
                    f"Missing local evidence media for {len(missing)} beat(s)"
                    if missing
                    else "All evidence-media beats have explicit local bindings",
                    missing_beats=missing,
                    resolved_beats=sorted(resolved),
                )
            )

        reuse_beats = [b for b in visual_plan.beats if b.media_type is VisualMediaType.ASSET_REUSE]
        if reuse_beats:
            try:
                resolved, _fingerprint = derive_asset_reuse_sources(visual_plan)
            except AmbiguousAssetReuseKeyError as exc:
                checks.append(
                    _check("ASSET_REUSE_BINDINGS", ReadinessStatus.BLOCK, str(exc))
                )
            else:
                missing_keys = sorted(
                    {
                        (b.reuse_key or "").strip()
                        for b in reuse_beats
                        if not (b.reuse_key or "").strip() or (b.reuse_key or "").strip() not in resolved
                    }
                )
                checks.append(
                    _check(
                        "ASSET_REUSE_BINDINGS",
                        ReadinessStatus.BLOCK if missing_keys else ReadinessStatus.PASS,
                        f"Unresolved ASSET_REUSE keys: {missing_keys}"
                        if missing_keys
                        else "All ASSET_REUSE beats resolve deterministically",
                        unresolved_keys=missing_keys,
                    )
                )

        if VisualMediaType.AI_HERO_VIDEO in media_types:
            hero_provider = env.get("MOTILY_HERO_VIDEO_PROVIDER", "disabled").strip().lower()
            ready = hero_provider == "gemini" and gemini_present
            reason = (
                "AI hero-video provider is configured"
                if ready
                else "VisualPlan contains AI_HERO_VIDEO but Gemini Veo is not enabled/configured"
            )
            checks.append(
                _check(
                    "HERO_VIDEO_PROVIDER",
                    ReadinessStatus.PASS if ready else ReadinessStatus.BLOCK,
                    reason,
                    provider=hero_provider,
                )
            )

    # Audio is optional until the user opts in. Once any production-audio
    # selection exists, the existing resolver enforces the full authored mix.
    try:
        audio = resolve_audio_asset_bindings(
            engine,
            WorkspaceBlobStore(Path(env.get("MOTILY_WORKSPACE_ROOT", str(workspace_root or DEFAULT_WORKSPACE_ROOT)))),
            project_id=project_id,
        )
    except ProductionAudioError as exc:
        checks.append(_check("PRODUCTION_AUDIO", ReadinessStatus.BLOCK, str(exc)))
    else:
        if audio.bindings is None:
            # A valid production may intentionally be narration-only.
            checks.append(
                _check(
                    "PRODUCTION_AUDIO",
                    ReadinessStatus.WARN,
                    "No music/SFX bindings selected; final render will be narration-only",
                )
            )
        else:
            checks.append(
                _check(
                    "PRODUCTION_AUDIO",
                    ReadinessStatus.PASS,
                    "Music/SFX program resolves completely",
                    source_asset_ids=audio.source_asset_ids,
                )
            )

    return ProductionReadinessReport.build(project_id, checks)
