from __future__ import annotations

from pathlib import Path
from uuid import UUID

from pydantic import model_validator

from app.models.common import MotilyModel, non_blank


class EvidenceMediaSource(MotilyModel):
    """One explicitly-bound local evidence image/video for one EVIDENCE_MEDIA beat.

    `source_id` is the exact ResearchPackage Source.source_id. The renderer
    receives only this already-resolved local contract and never queries the DB,
    searches the web, or guesses which evidence file belongs to a beat. Phase 42
    additionally carries optional clip bounds for video evidence; zero/None means
    "start at the beginning and use as much as the timeline segment needs."
    """

    source_id: str
    file_path: Path
    workspace_asset_id: UUID
    media_type: str | None = None
    clip_in_ms: int = 0
    clip_out_ms: int | None = None

    @model_validator(mode="after")
    def _check(self) -> "EvidenceMediaSource":
        non_blank(self.source_id, "source_id")
        non_blank(str(self.file_path), "file_path")
        if self.media_type is None:
            object.__setattr__(self, "media_type", self.file_path.suffix.lstrip(".").lower())
        non_blank(self.media_type, "media_type")
        if self.clip_in_ms < 0:
            raise ValueError("clip_in_ms must be >= 0")
        if self.clip_out_ms is not None and self.clip_out_ms <= self.clip_in_ms:
            raise ValueError("clip_out_ms must be greater than clip_in_ms when supplied")
        return self

    @property
    def is_video(self) -> bool:
        return self.media_type.lower() in {"mp4", "mov"}
