MOTILY STUDIO - DEVELOPMENT BUILD

1. Double-click INSTALL.bat.
2. Wait while Python dependencies are installed.
3. Motily Studio will open in your browser.
4. Future development builds can be installed from Studio using Check update -> Update & restart.

Data is kept under %LOCALAPPDATA%\MotilyStudio\data and is not replaced by code updates.
