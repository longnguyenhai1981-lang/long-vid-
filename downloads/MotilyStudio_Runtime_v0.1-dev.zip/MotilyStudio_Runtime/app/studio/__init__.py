"""Local Motily Studio web UI.

The web stack is imported lazily so small local utilities (for example the
updater) do not eagerly import production provider SDKs.
"""

from __future__ import annotations

from typing import Any

__all__ = ["create_studio_app"]


def __getattr__(name: str) -> Any:
    if name == "create_studio_app":
        from app.studio.web import create_studio_app

        return create_studio_app
    raise AttributeError(name)
