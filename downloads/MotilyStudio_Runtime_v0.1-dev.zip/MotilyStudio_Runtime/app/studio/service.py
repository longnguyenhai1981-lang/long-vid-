from __future__ import annotations

from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.bootstrap import AppComposition
from app.orchestration.models import ProductionNodeStatus
from app.production_audio.errors import ProductionAudioError
from app.production_readiness import inspect_production_readiness
from app.services.evidence_media_service import EvidenceMediaService
from app.services.production_audio_service import ProductionAudioService
from app.storage.production_runs import list_production_runs_for_project
from app.storage.projects import get_project, list_projects
from app.studio.models import StudioProjectSummary, StudioRunSummary
from app.workspace.storage import DEFAULT_WORKSPACE_ROOT, WorkspaceBlobStore


def _iso(value) -> str:
    return value.isoformat() if value is not None else ""


def run_summary(run) -> StudioRunSummary:
    nodes: list[dict] = []
    executed = reused = blocked = failed = 0
    for node_id, record in run.node_states.items():
        if record.executed_this_run:
            executed += 1
        if record.reused_existing_artifact:
            reused += 1
        if record.status is ProductionNodeStatus.BLOCKED:
            blocked += 1
        if record.status is ProductionNodeStatus.FAILED:
            failed += 1
        nodes.append(
            {
                "node_id": node_id,
                "status": record.status.value,
                "executed": record.executed_this_run,
                "reused": record.reused_existing_artifact,
                "reason": record.reason.value if record.reason else None,
                "artifact_id": record.artifact_id,
                "module_run_id": str(record.module_run_id) if record.module_run_id else None,
                "message": record.message,
            }
        )
    return StudioRunSummary(
        run_id=str(run.id),
        project_id=str(run.project_id),
        target_node=run.target_node,
        status=run.status.value,
        stop_reason=run.stop_reason,
        waiting_gate=run.waiting_gate,
        created_at=_iso(run.created_at),
        updated_at=_iso(run.updated_at),
        executed_count=executed,
        reused_count=reused,
        blocked_count=blocked,
        failed_count=failed,
        nodes=nodes,
    )


class StudioService:
    def __init__(self, composition: AppComposition, workspace_root: Path | str = DEFAULT_WORKSPACE_ROOT):
        self.composition = composition
        self.engine: Engine = composition.db_engine
        self.workspace_store = WorkspaceBlobStore(workspace_root)
        self.evidence = EvidenceMediaService(self.engine, self.workspace_store)
        self.audio = ProductionAudioService(self.engine, self.workspace_store)

    def projects(self) -> list[StudioProjectSummary]:
        out: list[StudioProjectSummary] = []
        for project in reversed(list_projects(self.engine)):
            runs = list_production_runs_for_project(self.engine, project.project_id)
            latest = runs[-1] if runs else None
            out.append(
                StudioProjectSummary(
                    project_id=str(project.project_id),
                    title=project.title_internal,
                    state=project.state.value,
                    created_at=_iso(project.created_at),
                    updated_at=_iso(project.updated_at),
                    latest_run_id=str(latest.id) if latest else None,
                    latest_run_status=latest.status.value if latest else None,
                )
            )
        return out

    def project(self, project_id: UUID) -> dict:
        project = get_project(self.engine, project_id)
        runs = list(reversed(list_production_runs_for_project(self.engine, project_id)))
        return {
            "project": {
                "project_id": str(project.project_id),
                "title": project.title_internal,
                "state": project.state.value,
                "created_at": _iso(project.created_at),
                "updated_at": _iso(project.updated_at),
                "artifact_refs": {
                    "idea_candidate_id": str(project.idea_candidate_id) if project.idea_candidate_id else None,
                    "research_r0_id": str(project.research_r0_id) if project.research_r0_id else None,
                    "feasibility_id": str(project.feasibility_id) if project.feasibility_id else None,
                    "research_r1_id": str(project.research_r1_id) if project.research_r1_id else None,
                    "narrative_plan_id": str(project.narrative_plan_id) if project.narrative_plan_id else None,
                    "packaging_prototype_id": str(project.packaging_prototype_id) if project.packaging_prototype_id else None,
                    "script_plan_id": str(project.script_plan_id) if project.script_plan_id else None,
                },
            },
            "runs": [run_summary(r).model_dump(mode="json") for r in runs],
        }

    def readiness(self, project_id: UUID) -> dict:
        report = inspect_production_readiness(self.engine, project_id, workspace_root=self.workspace_store.root)
        return report.model_dump(mode="json")

    def evidence_status(self, project_id: UUID) -> list[dict]:
        return [
            {
                "source_id": row.source_id,
                "title": row.title,
                "bound": row.bound,
                "beat_ids": list(row.beat_ids),
                "file_path": row.file_path,
                "workspace_asset_id": row.workspace_asset_id,
            }
            for row in self.evidence.status(project_id)
        ]

    def audio_status(self, project_id: UUID) -> dict:
        try:
            resolution = self.audio.resolve(project_id)
        except ProductionAudioError as exc:
            return {"enabled": False, "error": f"{type(exc).__name__}: {exc}", "fingerprint": None, "music_bed_path": None, "sfx_references": [], "source_asset_ids": []}
        bindings = resolution.bindings
        return {
            "enabled": bindings is not None,
            "error": None,
            "fingerprint": resolution.fingerprint,
            "music_bed_path": str(bindings.music_bed_path) if bindings and bindings.music_bed_path else None,
            "sfx_references": sorted(bindings.sfx_by_id) if bindings else [],
            "source_asset_ids": list(resolution.source_asset_ids),
        }
