from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import tomllib
from typing import Any
from uuid import uuid4
from zipfile import ZipFile, ZipInfo


class DevUpdateError(RuntimeError):
    """Base error for the local development updater."""


class InvalidUpdateArchiveError(DevUpdateError):
    pass


class UpdateNotFoundError(DevUpdateError):
    pass


class UpdateApplyError(DevUpdateError):
    pass


@dataclass(frozen=True)
class StagedUpdate:
    update_id: str
    filename: str
    sha256: str
    version: str
    staged_at: str
    build_id: str
    project_root: Path
    extracted_root: Path
    remote_revision: str | None = None
    remote_source: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "update_id": self.update_id,
            "filename": self.filename,
            "sha256": self.sha256,
            "version": self.version,
            "staged_at": self.staged_at,
            "build_id": self.build_id,
            "remote_revision": self.remote_revision,
            "remote_source": self.remote_source,
        }


class DevUpdateManager:
    """Validate, stage and apply development ZIP builds.

    Network retrieval is deliberately handled by ``update_channel``; this class
    only consumes local ZIP files, then replaces project-controlled paths with
    rollback on copy failure. Runtime data, virtualenvs and VCS metadata are
    never touched.
    """

    MANAGED_PATHS = (
        "app",
        "docs",
        "scripts",
        "tests",
        "pyproject.toml",
        "README.md",
        ".gitignore",
    )
    REQUIRED_PATHS = ("app", "pyproject.toml")
    MAX_ARCHIVE_FILES = 20_000
    MAX_UNCOMPRESSED_BYTES = 1 * 1024 * 1024 * 1024  # 1 GiB development-build ceiling

    def __init__(self, project_root: Path | str, update_root: Path | str):
        self.project_root = Path(project_root).resolve()
        self.update_root = Path(update_root).resolve()
        self.staging_root = self.update_root / "staging"
        self.backup_root = self.update_root / "backups"
        self.staging_root.mkdir(parents=True, exist_ok=True)
        self.backup_root.mkdir(parents=True, exist_ok=True)

    @property
    def current_version(self) -> str:
        return self._read_version(self.project_root)

    @staticmethod
    def _read_version(root: Path) -> str:
        pyproject = root / "pyproject.toml"
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
            return str(data.get("project", {}).get("version") or "dev")
        except (OSError, tomllib.TOMLDecodeError):
            return "dev"


    @staticmethod
    def _tree_fingerprint(root: Path) -> str:
        digest = hashlib.sha256()
        candidates: list[Path] = []
        app_dir = root / "app"
        if app_dir.exists():
            candidates.extend(p for p in app_dir.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
        if (root / "pyproject.toml").is_file():
            candidates.append(root / "pyproject.toml")
        for path in sorted(candidates, key=lambda p: p.relative_to(root).as_posix()):
            rel = path.relative_to(root).as_posix().encode("utf-8")
            digest.update(len(rel).to_bytes(4, "big")); digest.update(rel)
            with path.open("rb") as fh:
                for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                    digest.update(chunk)
        return digest.hexdigest()[:12]

    @staticmethod
    def _hash_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _is_zip_symlink(info: ZipInfo) -> bool:
        # Unix file type bits are stored in the upper 16 bits when present.
        return ((info.external_attr >> 16) & 0o170000) == 0o120000

    @classmethod
    def _safe_extract(cls, archive: Path, destination: Path) -> None:
        try:
            zf = ZipFile(archive)
        except Exception as exc:  # noqa: BLE001
            raise InvalidUpdateArchiveError(f"Not a readable ZIP archive: {exc}") from exc
        with zf:
            infos = zf.infolist()
            if not infos:
                raise InvalidUpdateArchiveError("Update ZIP is empty")
            if len(infos) > cls.MAX_ARCHIVE_FILES:
                raise InvalidUpdateArchiveError("Update ZIP contains too many files")
            total_uncompressed = sum(info.file_size for info in infos)
            if total_uncompressed > cls.MAX_UNCOMPRESSED_BYTES:
                raise InvalidUpdateArchiveError("Update ZIP exceeds the 1 GiB uncompressed safety limit")
            for info in infos:
                raw = info.filename.replace("\\", "/")
                path = PurePosixPath(raw)
                if path.is_absolute() or ".." in path.parts or (path.parts and ":" in path.parts[0]):
                    raise InvalidUpdateArchiveError(f"Unsafe archive path: {info.filename!r}")
                if cls._is_zip_symlink(info):
                    raise InvalidUpdateArchiveError(f"Symlinks are not allowed in update ZIPs: {info.filename!r}")
            zf.extractall(destination)

    @classmethod
    def _locate_project_root(cls, extracted: Path) -> Path:
        if all((extracted / p).exists() for p in cls.REQUIRED_PATHS):
            return extracted
        children = [p for p in extracted.iterdir() if p.is_dir()]
        candidates = [p for p in children if all((p / q).exists() for q in cls.REQUIRED_PATHS)]
        if len(candidates) == 1:
            return candidates[0]
        raise InvalidUpdateArchiveError("ZIP must contain a Motily project root with app/ and pyproject.toml")

    def stage(
        self,
        archive: Path | str,
        *,
        original_filename: str | None = None,
        remote_revision: str | None = None,
        remote_source: str | None = None,
    ) -> StagedUpdate:
        archive = Path(archive).resolve()
        if not archive.is_file():
            raise InvalidUpdateArchiveError(f"Update ZIP does not exist: {archive}")
        sha = self._hash_file(archive)
        update_id = f"{sha[:12]}-{uuid4().hex[:6]}"
        stage_dir = self.staging_root / update_id
        extract_dir = stage_dir / "files"
        extract_dir.mkdir(parents=True)
        try:
            self._safe_extract(archive, extract_dir)
            source_root = self._locate_project_root(extract_dir)
            version = self._read_version(source_root)
            build_id = self._tree_fingerprint(source_root)
            record = {
                "update_id": update_id,
                "filename": original_filename or archive.name,
                "sha256": sha,
                "version": version,
                "build_id": build_id,
                "staged_at": datetime.now(timezone.utc).isoformat(),
                "project_rel": source_root.relative_to(stage_dir).as_posix(),
                "remote_revision": remote_revision,
                "remote_source": remote_source,
            }
            (stage_dir / "metadata.json").write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
        except Exception:
            shutil.rmtree(stage_dir, ignore_errors=True)
            raise
        return self.get(update_id)

    def get(self, update_id: str) -> StagedUpdate:
        # Restrict ids to direct children of staging root.
        if not update_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in update_id):
            raise UpdateNotFoundError(update_id)
        stage_dir = self.staging_root / update_id
        meta = stage_dir / "metadata.json"
        try:
            record = json.loads(meta.read_text(encoding="utf-8"))
            source_root = (stage_dir / record["project_rel"]).resolve()
            source_root.relative_to(stage_dir.resolve())
        except Exception as exc:  # noqa: BLE001
            raise UpdateNotFoundError(update_id) from exc
        return StagedUpdate(
            update_id=record["update_id"], filename=record["filename"], sha256=record["sha256"],
            version=record["version"], staged_at=record["staged_at"], build_id=record.get("build_id") or self._tree_fingerprint(source_root), project_root=self.project_root,
            extracted_root=source_root,
            remote_revision=record.get("remote_revision"),
            remote_source=record.get("remote_source"),
        )

    def latest_staged(self) -> StagedUpdate | None:
        records: list[StagedUpdate] = []
        for child in self.staging_root.iterdir():
            if not child.is_dir():
                continue
            try:
                records.append(self.get(child.name))
            except UpdateNotFoundError:
                continue
        return max(records, key=lambda item: item.staged_at) if records else None

    @property
    def installed_remote_revision(self) -> str | None:
        state = self.update_root / "remote_state.json"
        try:
            record = json.loads(state.read_text(encoding="utf-8"))
            value = record.get("installed_revision")
            return str(value) if value else None
        except (OSError, ValueError, TypeError):
            return None

    def _record_remote_install(self, staged: StagedUpdate) -> None:
        if not staged.remote_revision:
            return
        state = {
            "installed_revision": staged.remote_revision,
            "remote_source": staged.remote_source,
            "installed_at": datetime.now(timezone.utc).isoformat(),
        }
        target = self.update_root / "remote_state.json"
        tmp = target.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(target)

    def status(self) -> dict[str, Any]:
        staged = self.latest_staged()
        return {
            "current_version": self.current_version,
            "current_build_id": self._tree_fingerprint(self.project_root),
            "source_root": str(self.project_root),
            "staged": staged.as_dict() if staged else None,
            "restart_recommended": False,
            "installed_remote_revision": self.installed_remote_revision,
        }

    def apply(self, update_id: str) -> dict[str, Any]:
        staged = self.get(update_id)
        previous_version = self.current_version
        previous_build_id = self._tree_fingerprint(self.project_root)
        source = staged.extracted_root
        backup = self.backup_root / update_id
        if backup.exists():
            raise UpdateApplyError(f"Update {update_id} has already been applied")
        backup.mkdir(parents=True)
        moved_old: list[tuple[Path, Path]] = []
        installed_new: list[Path] = []
        try:
            for name in self.MANAGED_PATHS:
                incoming = source / name
                if not incoming.exists():
                    # Optional paths absent from an update remain untouched.
                    continue
                current = self.project_root / name
                saved = backup / name
                if current.exists():
                    saved.parent.mkdir(parents=True, exist_ok=True)
                    current.rename(saved)
                    moved_old.append((saved, current))
                if incoming.is_dir():
                    shutil.copytree(incoming, current)
                else:
                    current.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(incoming, current)
                installed_new.append(current)
        except Exception as exc:  # noqa: BLE001
            for path in reversed(installed_new):
                if path.is_dir():
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    path.unlink(missing_ok=True)
            for saved, original in reversed(moved_old):
                original.parent.mkdir(parents=True, exist_ok=True)
                saved.rename(original)
            shutil.rmtree(backup, ignore_errors=True)
            raise UpdateApplyError(f"Update failed and was rolled back: {exc}") from exc

        receipt = {
            "update_id": update_id,
            "previous_version": previous_version,
            "installed_version": staged.version,
            "previous_build_id": previous_build_id,
            "installed_build_id": staged.build_id,
            "sha256": staged.sha256,
            "applied_at": datetime.now(timezone.utc).isoformat(),
            "restart_required": True,
            "backup_path": str(backup),
        }
        (backup / "apply_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True), encoding="utf-8")
        self._record_remote_install(staged)
        return receipt


def source_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def default_update_root(project_root: Path | None = None) -> Path:
    root = project_root or source_project_root()
    configured = os.environ.get("MOTILY_STUDIO_UPDATE_ROOT")
    return Path(configured).resolve() if configured else (root / "data" / "studio_updates").resolve()


def restart_command() -> list[str] | None:
    """Return the exact current command only for a real ``... studio ...`` launch."""
    argv = list(sys.argv)
    if len(argv) < 2:
        return None
    if not any(str(arg).lower() == "studio" for arg in argv[1:]):
        return None
    return argv


def spawn_restart_helper(command: list[str], *, cwd: Path, parent_pid: int | None = None) -> None:
    """Spawn a detached helper which waits for this process and relaunches it.

    The helper script lives in the OS temp directory, outside the project tree,
    so applying an update cannot replace the code that performs the restart.
    """
    import subprocess

    parent_pid = parent_pid or os.getpid()
    helper_dir = Path(tempfile.mkdtemp(prefix="motily_restart_"))
    helper = helper_dir / "restart.py"
    helper.write_text(
        """import json, os, subprocess, sys, time, shutil\n"
        "pid=int(sys.argv[1]); cwd=sys.argv[2]; cmd=json.loads(sys.argv[3]); home=sys.argv[4]\n"
        "for _ in range(120):\n"
        "    try: os.kill(pid, 0)\n"
        "    except OSError: break\n"
        "    time.sleep(0.1)\n"
        "kwargs={'cwd': cwd}\n"
        "if os.name == 'nt': kwargs['creationflags']=0x00000008|0x00000200\n"
        "else: kwargs['start_new_session']=True\n"
        "subprocess.Popen(cmd, **kwargs)\n"
        "time.sleep(1)\n"
        "shutil.rmtree(home, ignore_errors=True)\n"
        """,
        encoding="utf-8",
    )
    args = [sys.executable, str(helper), str(parent_pid), str(cwd), json.dumps(command), str(helper_dir)]
    kwargs: dict[str, Any] = {"cwd": str(cwd)}
    if os.name == "nt":
        kwargs["creationflags"] = 0x00000008 | 0x00000200
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(args, **kwargs)
