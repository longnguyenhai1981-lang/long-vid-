@echo off
setlocal EnableExtensions
title Motily Studio Installer
echo.
echo ========================================
echo          MOTILY STUDIO INSTALLER
echo ========================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\MotilyStudio"
set "APP_DIR=%INSTALL_DIR%\app"
set "VENV_DIR=%INSTALL_DIR%\.venv"

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\data" mkdir "%INSTALL_DIR%\data"

echo [1/5] Copying Motily Studio...
if exist "%APP_DIR%" rmdir /s /q "%APP_DIR%"
xcopy /e /i /y "%~dp0app" "%APP_DIR%" >nul
if exist "%INSTALL_DIR%\ti_assets_v1" rmdir /s /q "%INSTALL_DIR%\ti_assets_v1"
if exist "%~dp0ti_assets_v1" xcopy /e /i /y "%~dp0ti_assets_v1" "%INSTALL_DIR%\ti_assets_v1" >nul
copy /y "%~dp0pyproject.toml" "%INSTALL_DIR%\pyproject.toml" >nul

echo [2/5] Finding Python 3.11+...
set "PY_CMD="
py -3.12 -c "import sys" >nul 2>&1 && set "PY_CMD=py -3.12"
if not defined PY_CMD py -3.11 -c "import sys" >nul 2>&1 && set "PY_CMD=py -3.11"
if not defined PY_CMD python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1 && set "PY_CMD=python"
if not defined PY_CMD (
  echo Python 3.11+ was not found. Trying winget Python 3.12 installation...
  where winget >nul 2>&1 || goto :python_fail
  winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements
  py -3.12 -c "import sys" >nul 2>&1 && set "PY_CMD=py -3.12"
)
if not defined PY_CMD goto :python_fail

echo [3/5] Creating isolated environment...
if not exist "%VENV_DIR%\Scripts\python.exe" %PY_CMD% -m venv "%VENV_DIR%"
if errorlevel 1 goto :fail
"%VENV_DIR%\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
pushd "%INSTALL_DIR%"
"%VENV_DIR%\Scripts\python.exe" -m pip install -e .
if errorlevel 1 (popd & goto :fail)
popd

echo [4/5] Checking FFmpeg...
where ffmpeg >nul 2>&1
if errorlevel 1 (
  where winget >nul 2>&1 && winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
)

echo [5/5] Creating launcher...
>"%INSTALL_DIR%\START_MOTILY_STUDIO.cmd" echo @echo off
>>"%INSTALL_DIR%\START_MOTILY_STUDIO.cmd" echo cd /d "%%LOCALAPPDATA%%\MotilyStudio"
>>"%INSTALL_DIR%\START_MOTILY_STUDIO.cmd" echo "%%LOCALAPPDATA%%\MotilyStudio\.venv\Scripts\python.exe" -m app.cli.main studio

powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Motily Studio.lnk'); $s.TargetPath='%INSTALL_DIR%\START_MOTILY_STUDIO.cmd'; $s.WorkingDirectory='%INSTALL_DIR%'; $s.Save()" >nul 2>&1

echo.
echo Installation complete.
echo Opening Motily Studio...
start "" "%INSTALL_DIR%\START_MOTILY_STUDIO.cmd"
exit /b 0

:python_fail
echo.
echo ERROR: Python 3.11+ could not be installed or found.
pause
exit /b 1

:fail
echo.
echo ERROR: Motily Studio installation failed.
pause
exit /b 1
