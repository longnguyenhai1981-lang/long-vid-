from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class StudioProjectSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project_id: str
    title: str
    state: str
    created_at: str
    updated_at: str
    latest_run_id: str | None = None
    latest_run_status: str | None = None


class StudioRunSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: str
    project_id: str
    target_node: str
    status: str
    stop_reason: str | None = None
    waiting_gate: str | None = None
    created_at: str
    updated_at: str
    executed_count: int
    reused_count: int
    blocked_count: int
    failed_count: int
    nodes: list[dict[str, Any]] = Field(default_factory=list)


class StartProductionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project_id: str | None = None
    brief: str | None = None
    title: str | None = None
    target: str = "final"
    domain: str = "physics"
    discovery_mode: str = "open"
    additional_context: str | None = None


class GateDecisionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    gate: str | None = None
    note: str | None = None


class StudioActionResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ok: bool = True
    message: str
    run: StudioRunSummary | None = None
    data: dict[str, Any] = Field(default_factory=dict)


class UpdateChannelConfigRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repository: str
    branch: str = "main"
