from __future__ import annotations

from enum import Enum
from uuid import UUID

from pydantic import Field, model_validator

from app.models.common import MotilyModel


class ReadinessStatus(str, Enum):
    PASS = "PASS"
    WARN = "WARN"
    BLOCK = "BLOCK"


class ReadinessCheck(MotilyModel):
    check_id: str
    status: ReadinessStatus
    message: str
    details: dict[str, object] = Field(default_factory=dict)


class ProductionReadinessReport(MotilyModel):
    project_id: UUID
    checks: list[ReadinessCheck]
    overall_status: ReadinessStatus

    @model_validator(mode="after")
    def _derive_status(self) -> "ProductionReadinessReport":
        expected = ReadinessStatus.PASS
        if any(c.status is ReadinessStatus.BLOCK for c in self.checks):
            expected = ReadinessStatus.BLOCK
        elif any(c.status is ReadinessStatus.WARN for c in self.checks):
            expected = ReadinessStatus.WARN
        if self.overall_status is not expected:
            raise ValueError(
                f"overall_status must be derived from checks: expected {expected.value}, got {self.overall_status.value}"
            )
        return self

    @classmethod
    def build(cls, project_id: UUID, checks: list[ReadinessCheck]) -> "ProductionReadinessReport":
        overall = ReadinessStatus.PASS
        if any(c.status is ReadinessStatus.BLOCK for c in checks):
            overall = ReadinessStatus.BLOCK
        elif any(c.status is ReadinessStatus.WARN for c in checks):
            overall = ReadinessStatus.WARN
        return cls(project_id=project_id, checks=checks, overall_status=overall)
