"""Explicit local music/SFX binding for production execution.

This package resolves user-provided workspace audio into Phase-30
AudioAssetBindings. It performs no search, recommendation, generation, or fuzzy
matching. TimelineCue.reference is the authoritative SFX id.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

from sqlalchemy import Engine

from app.models.timeline import TimelineCueType, TimelineManifest
from app.production_audio.errors import (
    InvalidSFXReferenceError,
    MissingProductionMusicBindingError,
    MissingProductionSFXBindingError,
    ProductionAudioAssetProjectMismatchError,
    ProductionAudioAssetTypeError,
    ProductionAudioFileMissingError,
    ProductionAudioUnsupportedFormatError,
)
from app.production_audio.models import AudioBindingResolution
from app.renderers.timeline.models import TIMELINE_MANIFEST_ARTIFACT_TYPE
from app.storage.artifacts import get_artifact
from app.storage.errors import ArtifactNotFoundError
from app.storage.workspace_assets import (
    get_workspace_asset,
    get_workspace_asset_selection,
    save_workspace_asset_selection,
)
from app.video_encoder.models import AudioAssetBindings
from app.workspace.ingest import ingest_workspace_file
from app.workspace.models import AssetOrigin, WorkspaceAssetSelection, WorkspaceAssetType
from app.workspace.storage import WorkspaceBlobStore

_SUPPORTED_AUDIO_EXTENSIONS = frozenset({"wav", "mp3", "m4a", "aac"})
MUSIC_BED_ROLE = "PRODUCTION_AUDIO:MUSIC_BED"
_SFX_ROLE_PREFIX = "PRODUCTION_AUDIO:SFX:"


def sfx_selection_role(reference: str) -> str:
    ref = reference.strip()
    if not ref:
        raise InvalidSFXReferenceError("SFX reference cannot be blank")
    return f"{_SFX_ROLE_PREFIX}{ref}"


def _validate_audio_path(path: Path) -> None:
    ext = path.suffix.lstrip(".").lower()
    if ext not in _SUPPORTED_AUDIO_EXTENSIONS:
        raise ProductionAudioUnsupportedFormatError(
            f"Production audio must be one of {sorted(_SUPPORTED_AUDIO_EXTENSIONS)}, got {ext!r}"
        )


def bind_local_music_bed(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
    source_path: Path | str,
):
    path = Path(source_path)
    _validate_audio_path(path)
    asset = ingest_workspace_file(
        engine,
        blob_store,
        project_id=project_id,
        source_path=path,
        asset_type=WorkspaceAssetType.MUSIC_ASSET,
        origin=AssetOrigin.USER_PROVIDED,
        logical_name="MUSIC_BED",
    )
    save_workspace_asset_selection(
        engine,
        WorkspaceAssetSelection(
            project_id=project_id,
            role=MUSIC_BED_ROLE,
            asset_id=asset.id,
            updated_at=datetime.now(timezone.utc),
        ),
    )
    return asset


def bind_local_sfx(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
    reference: str,
    source_path: Path | str,
):
    role = sfx_selection_role(reference)
    path = Path(source_path)
    _validate_audio_path(path)
    asset = ingest_workspace_file(
        engine,
        blob_store,
        project_id=project_id,
        source_path=path,
        asset_type=WorkspaceAssetType.SFX_ASSET,
        origin=AssetOrigin.USER_PROVIDED,
        logical_name=reference.strip(),
    )
    save_workspace_asset_selection(
        engine,
        WorkspaceAssetSelection(
            project_id=project_id,
            role=role,
            asset_id=asset.id,
            updated_at=datetime.now(timezone.utc),
        ),
    )
    return asset


def _resolve_selected_asset(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
    role: str,
    expected_type: WorkspaceAssetType,
):
    selection = get_workspace_asset_selection(engine, project_id, role)
    if selection is None:
        return None
    asset = get_workspace_asset(engine, selection.asset_id)
    if asset.project_id != project_id:
        raise ProductionAudioAssetProjectMismatchError(
            f"Audio asset {asset.id} belongs to {asset.project_id}, expected {project_id}"
        )
    if asset.asset_type is not expected_type:
        raise ProductionAudioAssetTypeError(
            f"Audio binding {role!r} points to {asset.asset_type.value}, expected {expected_type.value}"
        )
    if asset.media_type not in _SUPPORTED_AUDIO_EXTENSIONS:
        raise ProductionAudioUnsupportedFormatError(
            f"Bound audio asset {asset.id} has unsupported media_type {asset.media_type!r}"
        )
    path = blob_store.resolve(asset.stored_relative_path)
    if not path.is_file():
        raise ProductionAudioFileMissingError(
            f"Audio asset {asset.id} points to missing workspace blob {path}"
        )
    return selection, asset, path


def resolve_audio_asset_bindings(
    engine: Engine,
    blob_store: WorkspaceBlobStore,
    *,
    project_id: UUID,
) -> AudioBindingResolution:
    """Resolve exactly the audio assets required by the *current* timeline.

    No selected music and no selected timeline SFX => narration-only, bindings=None.
    Once any production-audio binding is present, the complete authored audio
    program must be resolvable: one music bed plus every SFX_TRIGGER reference.
    This preserves Phase 30's explicit failure semantics instead of silently
    dropping cues.
    """
    try:
        timeline = get_artifact(
            engine, project_id, TIMELINE_MANIFEST_ARTIFACT_TYPE, TimelineManifest
        )
    except ArtifactNotFoundError:
        return AudioBindingResolution()

    sfx_refs: list[str] = []
    for cue in timeline.cues:
        if cue.cue_type is TimelineCueType.SFX_TRIGGER:
            if not cue.reference or not cue.reference.strip():
                raise InvalidSFXReferenceError("Timeline SFX_TRIGGER cue has no reference")
            if cue.reference not in sfx_refs:
                sfx_refs.append(cue.reference)

    music = _resolve_selected_asset(
        engine, blob_store, project_id=project_id, role=MUSIC_BED_ROLE,
        expected_type=WorkspaceAssetType.MUSIC_ASSET,
    )
    selected_sfx = {
        ref: _resolve_selected_asset(
            engine, blob_store, project_id=project_id, role=sfx_selection_role(ref),
            expected_type=WorkspaceAssetType.SFX_ASSET,
        )
        for ref in sfx_refs
    }

    any_sfx_selected = any(value is not None for value in selected_sfx.values())
    if music is None and not any_sfx_selected:
        return AudioBindingResolution()
    if music is None:
        raise MissingProductionMusicBindingError(
            "At least one SFX is bound, but no production music bed is selected. "
            "Phase-30 mixing is an explicit full-program opt-in; bind MUSIC_BED first."
        )

    missing_sfx = [ref for ref, value in selected_sfx.items() if value is None]
    if missing_sfx:
        raise MissingProductionSFXBindingError(
            f"Current timeline requires unbound SFX references: {missing_sfx}"
        )

    _music_selection, music_asset, music_path = music
    sfx_by_id: dict[str, Path] = {}
    source_asset_ids = [str(music_asset.id)]
    fingerprint_parts = [f"music:{music_asset.id}:{music_asset.sha256}"]
    for ref in sfx_refs:
        _selection, asset, path = selected_sfx[ref]  # type: ignore[misc]
        sfx_by_id[ref] = path
        source_asset_ids.append(str(asset.id))
        fingerprint_parts.append(f"sfx:{ref}:{asset.id}:{asset.sha256}")

    fingerprint = hashlib.sha256("\n".join(fingerprint_parts).encode("utf-8")).hexdigest()
    return AudioBindingResolution(
        bindings=AudioAssetBindings(music_bed_path=music_path, sfx_by_id=sfx_by_id),
        fingerprint=fingerprint,
        source_asset_ids=source_asset_ids,
    )
