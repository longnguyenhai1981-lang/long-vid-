from __future__ import annotations

from pydantic import Field

from app.models.common import MotilyModel
from app.video_encoder.models import AudioAssetBindings


class AudioBindingResolution(MotilyModel):
    """Already-resolved local production-audio program for one current timeline.

    `bindings=None` means the project has not opted into Phase-30 music/SFX
    execution at all, so VideoRenderer must preserve narration-only behavior.
    The fingerprint is stable over the exact workspace assets used.
    """

    bindings: AudioAssetBindings | None = None
    fingerprint: str | None = None
    source_asset_ids: list[str] = Field(default_factory=list)
