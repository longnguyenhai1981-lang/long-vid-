"""Provider-neutral request/response models for rare AI hero-video beats."""

from __future__ import annotations

from pydantic import Field, model_validator

from app.models.common import MotilyModel, non_blank


class HeroVideoRenderRequest(MotilyModel):
    render_job_id: str
    beat_id: str
    concept: str
    primary_focus: str
    secondary_elements: list[str] = Field(default_factory=list)
    context_elements: list[str] = Field(default_factory=list)
    motion_intent: str | None = None
    aspect_ratio: str = "16:9"
    resolution: str = "720p"
    metadata: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_invariants(self) -> "HeroVideoRenderRequest":
        non_blank(self.render_job_id, "render_job_id")
        non_blank(self.beat_id, "beat_id")
        non_blank(self.concept, "concept")
        non_blank(self.primary_focus, "primary_focus")
        if self.aspect_ratio not in {"16:9", "9:16"}:
            raise ValueError("aspect_ratio must be '16:9' or '9:16'")
        if self.resolution not in {"720p", "1080p", "4k"}:
            raise ValueError("resolution must be one of '720p', '1080p', '4k'")
        return self


class HeroVideoRenderResponse(MotilyModel):
    video_bytes: bytes
    provider: str
    model: str
    provider_request_id: str | None = None
    duration_ms: int | None = None
    mime_type: str = "video/mp4"
    metadata: dict[str, str] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_invariants(self) -> "HeroVideoRenderResponse":
        if not self.video_bytes:
            raise ValueError("video_bytes cannot be empty")
        non_blank(self.provider, "provider")
        non_blank(self.model, "model")
        non_blank(self.mime_type, "mime_type")
        if self.mime_type != "video/mp4":
            raise ValueError(f"unsupported hero-video MIME type {self.mime_type!r}; expected 'video/mp4'")
        if self.duration_ms is not None and self.duration_ms <= 0:
            raise ValueError("duration_ms must be > 0 when supplied")
        return self
