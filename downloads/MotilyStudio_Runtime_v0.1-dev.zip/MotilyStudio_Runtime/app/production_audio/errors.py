from __future__ import annotations


class ProductionAudioError(Exception):
    """Base class for deterministic production-audio binding errors."""


class ProductionAudioUnsupportedFormatError(ProductionAudioError):
    pass


class ProductionAudioAssetTypeError(ProductionAudioError):
    pass


class ProductionAudioAssetProjectMismatchError(ProductionAudioError):
    pass


class ProductionAudioFileMissingError(ProductionAudioError):
    pass


class MissingProductionMusicBindingError(ProductionAudioError):
    pass


class MissingProductionSFXBindingError(ProductionAudioError):
    pass


class InvalidSFXReferenceError(ProductionAudioError):
    pass
