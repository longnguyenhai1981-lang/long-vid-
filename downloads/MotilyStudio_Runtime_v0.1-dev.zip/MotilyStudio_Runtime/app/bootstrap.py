"""Application composition root.

Phase 36 added the first real LLM runtime wiring and Phase 37 added the
real Gemini/Google-Search research retriever.  Phase 38 completes the local
production runtime wiring for the already-existing downstream media stack:
Gemini TTS, the configured image provider, deterministic file stores,
canonical Tí compositing, and optional subtitle burn-in.

The orchestration core remains provider-unaware.  This module is the only
application-level place that chooses and constructs concrete production
runtime dependencies for normal CLI execution.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from uuid import UUID

from sqlalchemy import Engine

from app.audio.config import CANONICAL_TI_VOICE_ID, TTSSettings
from app.audio.providers.gemini import DEFAULT_GEMINI_MODEL as DEFAULT_GEMINI_TTS_MODEL
from app.audio.providers.gemini import GeminiTTSConfig, GeminiTTSProvider
from app.audio.storage import AudioFileStore
from app.captions.models import CaptionRenderSettings
from app.captions.storage import SubtitleFileStore
from app.evidence_media.service import resolve_evidence_media_sources
from app.hero_video.config import HeroVideoSettings
from app.hero_video.providers.gemini_veo import (
    DEFAULT_GEMINI_VEO_MODEL,
    GEMINI_VEO_PROVIDER_NAME,
    GeminiVeoConfig,
    GeminiVeoProvider,
)
from app.config.loader import load_global_config
from app.llm import LLMSettings
from app.llm.providers.gemini import DEFAULT_GEMINI_LLM_MODEL, GeminiLLMConfig, GeminiLLMProvider
from app.models.common import AudioFormat, VisualOutputFormat
from app.orchestration.graph import ProductionGraph
from app.orchestration.registry import ExecutionContext
from app.production_adapters.registry import build_full_adapters, build_full_graph
from app.production_audio.service import resolve_audio_asset_bindings
from app.research.providers.gemini import (
    DEFAULT_GEMINI_SEARCH_MODEL,
    GeminiSearchConfig,
    GeminiSearchRetriever,
)
from app.services.production_service import ProductionService
from app.storage.database import DEFAULT_DB_PATH, init_database
from app.storage.errors import TiAssetSetNotFoundError
from app.storage.ti_assets import get_active_ti_asset_set
from app.ti_assets.ingest import ingest_ti_asset_set
from app.ti_assets.retriever import SqliteTiAssetRetriever
from app.ti_assets.storage import DEFAULT_TI_ASSET_ROOT, TiAssetFileStore
from app.ti_compositor.compositor import TiCompositor
from app.video_encoder.storage import VideoFileStore
from app.visual.config import VisualSettings
from app.visual.canvas import VisualCanvasSpec
from app.visual.providers.cloudflare import (
    CLOUDFLARE_PROVIDER_NAME,
    CloudflareImageConfig,
    CloudflareImageProvider,
)
from app.visual.providers.gemini import (
    GEMINI_IMAGE_PROVIDER_NAME,
    GeminiImageConfig,
    GeminiImageProvider,
)
from app.visual.storage import VisualFileStore
from app.workspace.storage import WorkspaceBlobStore, DEFAULT_WORKSPACE_ROOT

DEFAULT_MEDIA_ROOT = Path("data/runtime")
DEFAULT_TI_SOURCE_DIR = Path("ti_assets_v1")
_SUPPORTED_VISUAL_PROVIDERS = {"cloudflare", "gemini"}
_SUPPORTED_HERO_VIDEO_PROVIDERS = {"disabled", "gemini"}


@dataclass(frozen=True)
class AppComposition:
    db_engine: Engine
    graph: ProductionGraph
    adapters: dict[str, object]
    service: ProductionService
    # Optional keeps Phase-35 callers/tests that construct AppComposition with
    # four positional fields fully backward compatible.
    context_factory: Callable[[UUID, Engine], ExecutionContext] | None = None


class _DeferredVisualProvider:
    """Construct a credential-bearing visual provider only when rendering.

    A production request targeting IDEA/SCRIPT must not require Cloudflare
    credentials merely because the *eventual* final target might render an
    image.  The configured provider choice is fixed at context construction;
    only its concrete client/credential resolution is deferred until the first
    VisualProvider.render() call.  No fallback or provider switching occurs.
    """

    def __init__(self, factory: Callable[[], object]):
        self._factory = factory
        self._provider: object | None = None

    def render(self, request):
        if self._provider is None:
            self._provider = self._factory()
        return self._provider.render(request)


class _DeferredHeroVideoProvider:
    """Delay Veo client/API-key construction until an AI_HERO_VIDEO beat
    actually renders. Provider choice remains fixed at context construction.
    """

    def __init__(self, factory: Callable[[], object]):
        self._factory = factory
        self._provider: object | None = None

    def render(self, request):
        if self._provider is None:
            self._provider = self._factory()
        return self._provider.render(request)


def _build_hero_video_runtime() -> tuple[object | None, HeroVideoSettings | None, str | None]:
    provider_name = os.environ.get("MOTILY_HERO_VIDEO_PROVIDER", "disabled").strip().lower()
    if provider_name not in _SUPPORTED_HERO_VIDEO_PROVIDERS:
        raise ValueError(
            "MOTILY_HERO_VIDEO_PROVIDER must be one of "
            f"{sorted(_SUPPORTED_HERO_VIDEO_PROVIDERS)}, got {provider_name!r}"
        )
    if provider_name == "disabled":
        return None, None, None

    model = os.environ.get("MOTILY_HERO_VIDEO_MODEL", DEFAULT_GEMINI_VEO_MODEL).strip()
    if not model:
        model = DEFAULT_GEMINI_VEO_MODEL
    aspect_ratio = os.environ.get("MOTILY_HERO_VIDEO_ASPECT_RATIO", "16:9").strip() or "16:9"
    resolution = os.environ.get("MOTILY_HERO_VIDEO_RESOLUTION", "720p").strip() or "720p"
    config = GeminiVeoConfig(
        model=model,
        poll_interval_seconds=_env_float("MOTILY_HERO_VIDEO_POLL_SECONDS", 10.0),
        max_wait_seconds=_env_float("MOTILY_HERO_VIDEO_MAX_WAIT_SECONDS", 300.0),
        default_aspect_ratio=aspect_ratio,
        default_resolution=resolution,
    )
    settings = HeroVideoSettings(
        provider=GEMINI_VEO_PROVIDER_NAME,
        max_provider_retries=_env_int("MOTILY_HERO_VIDEO_PROVIDER_RETRIES", 0),
        aspect_ratio=aspect_ratio,
        resolution=resolution,
    )
    fingerprint = f"{GEMINI_VEO_PROVIDER_NAME}:{model}:{aspect_ratio}:{resolution}"
    return _DeferredHeroVideoProvider(lambda: GeminiVeoProvider(config)), settings, fingerprint


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    return default if raw is None or not raw.strip() else int(raw)


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    return default if raw is None or not raw.strip() else float(raw)


def _media_root_for_project(project_id: UUID) -> Path:
    root = Path(os.environ.get("MOTILY_MEDIA_ROOT", str(DEFAULT_MEDIA_ROOT)))
    return root / str(project_id)


def _build_visual_runtime() -> tuple[object, VisualSettings]:
    provider_name = os.environ.get("MOTILY_VISUAL_PROVIDER", "cloudflare").strip().lower()
    if provider_name not in _SUPPORTED_VISUAL_PROVIDERS:
        raise ValueError(
            "MOTILY_VISUAL_PROVIDER must be one of "
            f"{sorted(_SUPPORTED_VISUAL_PROVIDERS)}, got {provider_name!r}"
        )

    retries = _env_int("MOTILY_VISUAL_PROVIDER_RETRIES", 1)
    if provider_name == "cloudflare":
        config = CloudflareImageConfig(
            model=os.environ.get("MOTILY_VISUAL_MODEL", CloudflareImageConfig().model).strip()
            or CloudflareImageConfig().model,
            timeout_seconds=_env_float("MOTILY_VISUAL_TIMEOUT_SECONDS", 60.0),
            steps=_env_int("MOTILY_VISUAL_STEPS", 4),
        )
        return (
            _DeferredVisualProvider(lambda: CloudflareImageProvider(config)),
            VisualSettings(
                provider=CLOUDFLARE_PROVIDER_NAME,
                output_format=VisualOutputFormat.JPG,
                max_provider_retries=retries,
            ),
        )

    config = GeminiImageConfig(
        model=os.environ.get("MOTILY_VISUAL_MODEL", GeminiImageConfig().model).strip()
        or GeminiImageConfig().model,
    )
    return (
        _DeferredVisualProvider(lambda: GeminiImageProvider(config)),
        VisualSettings(
            provider=GEMINI_IMAGE_PROVIDER_NAME,
            output_format=VisualOutputFormat.PNG,
            max_provider_retries=retries,
        ),
    )


def _build_ti_compositor(db_engine: Engine) -> TiCompositor:
    """Return the deterministic canonical-Tí compositor for this database.

    If the database has never registered a Tí set yet and the bundled/source
    directory exists, ingest it once.  This is deterministic local bootstrap,
    not image generation.  Existing active sets are never replaced.
    """

    ti_root = Path(os.environ.get("MOTILY_TI_ASSET_ROOT", str(DEFAULT_TI_ASSET_ROOT)))
    file_store = TiAssetFileStore(ti_root)
    try:
        get_active_ti_asset_set(db_engine)
    except TiAssetSetNotFoundError:
        source_dir = Path(os.environ.get("MOTILY_TI_SOURCE_DIR", str(DEFAULT_TI_SOURCE_DIR)))
        if source_dir.is_dir():
            ingest_ti_asset_set(
                db_engine,
                file_store,
                source_dir,
                version=os.environ.get("MOTILY_TI_ASSET_VERSION", "v1"),
                activate=True,
            )
    return TiCompositor(SqliteTiAssetRetriever(db_engine, file_store))


def build_execution_context(project_id: UUID, db_engine: Engine) -> ExecutionContext:
    """Build the normal production ExecutionContext for one CLI invocation.

    Provider/model selection is explicit application configuration, never an
    orchestration decision. API-key material is read only inside concrete
    providers and is not stored on ExecutionContext/ProductionRun.
    """

    llm_model = os.environ.get("MOTILY_LLM_MODEL", DEFAULT_GEMINI_LLM_MODEL).strip()
    if not llm_model:
        llm_model = DEFAULT_GEMINI_LLM_MODEL

    llm_settings = LLMSettings(
        provider="gemini",
        default_model=llm_model,
        max_structured_retries=_env_int("MOTILY_LLM_STRUCTURED_RETRIES", 2),
    )
    llm_provider = GeminiLLMProvider(
        GeminiLLMConfig(
            timeout_seconds=_env_float("MOTILY_LLM_TIMEOUT_SECONDS", 60.0),
            max_provider_retries=_env_int("MOTILY_LLM_PROVIDER_RETRIES", 1),
        )
    )

    search_model = os.environ.get("MOTILY_RESEARCH_MODEL", DEFAULT_GEMINI_SEARCH_MODEL).strip()
    if not search_model:
        search_model = DEFAULT_GEMINI_SEARCH_MODEL
    research_retriever = GeminiSearchRetriever(
        GeminiSearchConfig(
            model=search_model,
            timeout_seconds=_env_float("MOTILY_RESEARCH_TIMEOUT_SECONDS", 60.0),
            max_provider_retries=_env_int("MOTILY_RESEARCH_PROVIDER_RETRIES", 1),
        )
    )

    # Downstream media runtime.  Store roots are project-scoped because voice
    # render_job_ids are chunk-local (e.g. C001_T1) and therefore must never
    # collide across projects sharing the same application data directory.
    media_root = _media_root_for_project(project_id)
    audio_store = AudioFileStore(media_root / "audio")
    visual_store = VisualFileStore(media_root / "visuals")
    video_store = VideoFileStore(media_root / "video")
    subtitle_store = SubtitleFileStore(media_root / "subtitles")

    tts_model = os.environ.get("MOTILY_TTS_MODEL", DEFAULT_GEMINI_TTS_MODEL).strip()
    if not tts_model:
        tts_model = DEFAULT_GEMINI_TTS_MODEL
    tts_provider = GeminiTTSProvider(GeminiTTSConfig(model=tts_model))
    tts_settings = TTSSettings(
        provider="gemini",
        voice_id=os.environ.get("MOTILY_TTS_VOICE", CANONICAL_TI_VOICE_ID).strip()
        or CANONICAL_TI_VOICE_ID,
        output_format=AudioFormat.WAV,
        max_provider_retries=_env_int("MOTILY_TTS_PROVIDER_RETRIES", 1),
        default_model=tts_model,
    )

    visual_provider, visual_settings = _build_visual_runtime()
    hero_video_provider, hero_video_settings, hero_video_provider_fingerprint = _build_hero_video_runtime()

    burn_in_enabled = os.environ.get("MOTILY_BURN_CAPTIONS", "1").strip().lower() not in {
        "0",
        "false",
        "no",
        "off",
    }

    workspace_root = Path(os.environ.get("MOTILY_WORKSPACE_ROOT", str(DEFAULT_WORKSPACE_ROOT)))
    workspace_blob_store = WorkspaceBlobStore(workspace_root)
    evidence_media_sources, evidence_binding_fingerprint = resolve_evidence_media_sources(
        db_engine, workspace_blob_store, project_id=project_id
    )

    def _resolve_audio_bindings():
        # Resolve at VIDEO_RENDER execution time rather than context-build time: a
        # full production run may create the TimelineManifest only after this
        # ExecutionContext was constructed.
        return resolve_audio_asset_bindings(
            db_engine, workspace_blob_store, project_id=project_id
        )

    return ExecutionContext(
        db_engine=db_engine,
        project_id=project_id,
        llm_provider=llm_provider,
        llm_settings=llm_settings,
        global_config=load_global_config(),
        research_retriever=research_retriever,
        audio_store=audio_store,
        visual_store=visual_store,
        video_store=video_store,
        subtitle_store=subtitle_store,
        tts_provider=tts_provider,
        tts_settings=tts_settings,
        visual_provider=visual_provider,
        visual_settings=visual_settings,
        hero_video_provider=hero_video_provider,
        hero_video_settings=hero_video_settings,
        materialize_ai_hero_video=hero_video_provider is not None,
        hero_video_provider_fingerprint=hero_video_provider_fingerprint,
        production_visual_canvas=VisualCanvasSpec(
            width=_env_int("MOTILY_VIDEO_WIDTH", 1280),
            height=_env_int("MOTILY_VIDEO_HEIGHT", 720),
            background_color=os.environ.get("MOTILY_VIDEO_BACKGROUND", "#F4F0E8").strip() or "#F4F0E8",
        ),
        materialize_limited_motion=True,
        ti_compositor=_build_ti_compositor(db_engine),
        evidence_media_sources=evidence_media_sources,
        evidence_binding_fingerprint=evidence_binding_fingerprint,
        audio_binding_resolver=_resolve_audio_bindings,
        burn_in_settings=CaptionRenderSettings() if burn_in_enabled else None,
    )


def build_composition(db_path: Path | str = DEFAULT_DB_PATH) -> AppComposition:
    """Build the full 19-node production composition.

    Creating the composition itself does not require credentials.  Concrete
    production providers are constructed only when produce/resume requests an
    ExecutionContext; the visual provider's own credential-bearing client is
    deferred further until VISUAL_RENDER. Read-only CLI commands therefore
    continue to work on an unconfigured machine.
    """

    db_engine = init_database(db_path)
    graph = build_full_graph()
    adapters = build_full_adapters()
    service = ProductionService(db_engine, graph, adapters)
    return AppComposition(
        db_engine=db_engine,
        graph=graph,
        adapters=adapters,
        service=service,
        context_factory=build_execution_context,
    )
