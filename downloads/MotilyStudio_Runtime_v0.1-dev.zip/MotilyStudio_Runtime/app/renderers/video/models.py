"""Video Renderer input/output contracts.

EncodedVideoAsset (app/models/video.py) is the single approved business
output -- these are thin wrappers around it, not a competing schema.
"""

from __future__ import annotations

from uuid import UUID

from pydantic import Field, model_validator

from app.models.common import MotilyModel
from app.models.video import EncodedVideoAsset
from app.video_encoder.models import AudioAssetBindings

ENCODED_VIDEO_ASSET_ARTIFACT_TYPE = "encoded_video_asset"


class VideoRendererInput(MotilyModel):
    project_id: UUID
    audio_bindings: AudioAssetBindings | None = None
    audio_binding_fingerprint: str | None = None
    source_audio_asset_ids: list[str] = Field(default_factory=list)
    canvas_width: int | None = None
    canvas_height: int | None = None
    """Phase 30: explicit opt-in for music/SFX mix execution. None (the
    default) makes VideoRenderer behave exactly like Phase 29 -- the
    TimelineManifest's own MUSIC_*/SFX_TRIGGER cues are never even
    forwarded to VideoEncoder, regardless of what they contain, so every
    pre-Phase-30 caller needs zero changes. Passing an AudioAssetBindings
    (even an empty one) engages real mix execution: the manifest's cues
    ARE forwarded, and a music cue with no bound asset then fails
    explicitly (MissingMusicAssetError) rather than silently playing no
    music."""

    @model_validator(mode="after")
    def _check_canvas(self) -> "VideoRendererInput":
        supplied = sum(v is not None for v in (self.canvas_width, self.canvas_height))
        if supplied == 1:
            raise ValueError("canvas_width and canvas_height must be supplied together")
        if self.canvas_width is not None and (self.canvas_width <= 0 or self.canvas_height <= 0):
            raise ValueError("explicit canvas dimensions must be > 0")
        return self

    @property
    def has_explicit_canvas(self) -> bool:
        return self.canvas_width is not None and self.canvas_height is not None


class VideoRendererResult(MotilyModel):
    asset: EncodedVideoAsset
    module_run_id: UUID
