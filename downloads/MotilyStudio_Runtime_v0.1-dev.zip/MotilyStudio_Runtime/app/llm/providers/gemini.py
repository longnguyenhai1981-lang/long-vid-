"""Gemini implementation of Motily's provider-independent LLMProvider.

This is the only LLM-layer module that imports the Google GenAI SDK. Engines
continue to depend solely on ``LLMProvider`` and ``LLMRequest``/``LLMResponse``.
Structured-output validation remains owned by ``app.llm.structured``; this
adapter is deliberately a text-generation transport boundary.
"""

from __future__ import annotations

import os
import time
from typing import Any, Callable

import httpx
from google import genai
from google.genai import errors as genai_errors
from google.genai import types as genai_types
from pydantic import model_validator

from app.llm.errors import (
    LLMAuthenticationError,
    LLMConfigurationError,
    LLMProviderError,
    LLMRateLimitError,
    LLMResponseError,
    LLMTimeoutError,
    LLMTransportError,
)
from app.llm.models import LLMRequest, LLMResponse, TokenUsage
from app.models.common import MotilyModel, non_blank

GEMINI_LLM_PROVIDER_NAME = "gemini"
# Stable production model as of Phase 36. Callers still choose the model through
# LLMRequest/LLMSettings; this constant is only the production-bootstrap default.
DEFAULT_GEMINI_LLM_MODEL = "gemini-3.6-flash"


class GeminiLLMConfig(MotilyModel):
    api_key_env: str = "GEMINI_API_KEY"
    timeout_seconds: float = 60.0
    max_provider_retries: int = 1
    retry_backoff_seconds: float = 0.25

    @model_validator(mode="after")
    def _check_invariants(self) -> "GeminiLLMConfig":
        non_blank(self.api_key_env, "api_key_env")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        if self.max_provider_retries < 0:
            raise ValueError("max_provider_retries must be >= 0")
        if self.retry_backoff_seconds < 0:
            raise ValueError("retry_backoff_seconds must be >= 0")
        return self

    def __repr__(self) -> str:
        # Config stores only the environment-variable NAME, never its value.
        return (
            "GeminiLLMConfig("
            f"api_key_env={self.api_key_env!r}, timeout_seconds={self.timeout_seconds!r}, "
            f"max_provider_retries={self.max_provider_retries!r}, "
            f"retry_backoff_seconds={self.retry_backoff_seconds!r})"
        )


class GeminiLLMProvider:
    """Synchronous Gemini text provider satisfying :class:`LLMProvider`.

    A client may be injected for deterministic tests. When no client is
    supplied, the API key is read from ``config.api_key_env`` at construction
    and is never stored in any public model or emitted in errors/logging.
    """

    def __init__(
        self,
        config: GeminiLLMConfig | None = None,
        *,
        client: Any = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._config = config or GeminiLLMConfig()
        self._client = client if client is not None else _build_default_client(self._config)
        self._sleep = sleep

    @property
    def config(self) -> GeminiLLMConfig:
        return self._config

    def generate(self, request: LLMRequest) -> LLMResponse:
        config = _build_generate_config(request)
        attempts = self._config.max_provider_retries + 1

        for attempt in range(1, attempts + 1):
            try:
                response = self._client.models.generate_content(
                    model=request.model,
                    contents=request.user_prompt,
                    config=config,
                )
                return _to_llm_response(response, request)
            except Exception as exc:  # narrowed immediately by _classify_exception
                mapped, retryable = _classify_exception(exc)
                if mapped is None:
                    # Genuine adapter/programming errors must never be hidden behind a
                    # generic provider error.
                    raise
                if retryable and attempt < attempts:
                    if self._config.retry_backoff_seconds:
                        self._sleep(self._config.retry_backoff_seconds * attempt)
                    continue
                raise mapped from exc

        raise AssertionError("unreachable: Gemini retry loop exited without result")

    def __repr__(self) -> str:
        return f"GeminiLLMProvider(config={self._config!r})"


def _build_default_client(config: GeminiLLMConfig) -> genai.Client:
    api_key = os.environ.get(config.api_key_env)
    if not api_key:
        raise LLMConfigurationError(
            f"Environment variable {config.api_key_env!r} is not set; "
            "GeminiLLMProvider requires a Gemini API key"
        )
    return genai.Client(
        api_key=api_key,
        http_options=genai_types.HttpOptions(timeout=int(config.timeout_seconds * 1000)),
    )


def _build_generate_config(request: LLMRequest) -> genai_types.GenerateContentConfig:
    data: dict[str, Any] = {}
    if request.system_prompt:
        data["system_instruction"] = request.system_prompt
    if request.temperature is not None:
        data["temperature"] = request.temperature
    if request.max_output_tokens is not None:
        data["max_output_tokens"] = request.max_output_tokens
    return genai_types.GenerateContentConfig(**data)


def _to_llm_response(response: Any, request: LLMRequest) -> LLMResponse:
    try:
        text = response.text
    except Exception as exc:
        raise LLMResponseError("Gemini response did not contain readable text output") from exc

    if text is None or not str(text).strip():
        raise LLMResponseError("Gemini response contained no text output")

    usage = getattr(response, "usage_metadata", None)
    input_tokens = _nonnegative_int(getattr(usage, "prompt_token_count", None))
    output_tokens = _nonnegative_int(getattr(usage, "candidates_token_count", None))
    total_tokens = _nonnegative_int(getattr(usage, "total_token_count", None))
    # Some Gemini responses account for thoughts/cache in total_token_count, so
    # Motily's TokenUsage invariant only permits total when it is exactly input
    # + output. Preserve the provider total in metadata when it differs.
    token_usage_total = total_tokens
    metadata: dict[str, str] = {}
    if (
        input_tokens is not None
        and output_tokens is not None
        and total_tokens is not None
        and total_tokens != input_tokens + output_tokens
    ):
        metadata["provider_total_tokens"] = str(total_tokens)
        token_usage_total = None

    model_version = getattr(response, "model_version", None)
    if model_version:
        metadata["model_version"] = str(model_version)

    finish_reason = None
    candidates = getattr(response, "candidates", None) or []
    if candidates:
        raw_reason = getattr(candidates[0], "finish_reason", None)
        if raw_reason is not None:
            finish_reason = getattr(raw_reason, "value", None) or str(raw_reason)

    return LLMResponse(
        text=str(text),
        provider=GEMINI_LLM_PROVIDER_NAME,
        model=request.model,
        usage=TokenUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=token_usage_total,
        ),
        finish_reason=finish_reason,
        provider_request_id=getattr(response, "response_id", None),
        metadata=metadata,
    )


def _nonnegative_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        converted = int(value)
    except (TypeError, ValueError):
        return None
    return converted if converted >= 0 else None


def _classify_exception(exc: Exception) -> tuple[LLMProviderError | None, bool]:
    """Return ``(mapped_error, retryable)`` for known SDK/transport errors.

    Error messages intentionally avoid raw response bodies/details because SDK
    exception text is not guaranteed to be secret-safe.
    """
    if isinstance(exc, httpx.TimeoutException):
        return LLMTimeoutError("Gemini request timed out"), True
    if isinstance(exc, httpx.TransportError):
        return LLMTransportError("Gemini transport request failed"), True
    if isinstance(exc, genai_errors.APIError):
        code = int(getattr(exc, "code", 0) or 0)
        status = getattr(exc, "status", None)
        suffix = f" ({code}{' ' + str(status) if status else ''})" if code or status else ""
        if code in (401, 403):
            return LLMAuthenticationError(f"Gemini authentication/authorization failed{suffix}"), False
        if code == 429:
            return LLMRateLimitError(f"Gemini rate limit exceeded{suffix}"), True
        if 500 <= code < 600:
            return LLMProviderError(f"Gemini provider temporarily failed{suffix}"), True
        return LLMProviderError(f"Gemini provider request failed{suffix}"), False
    return None, False
