"""Deterministic raster-canvas normalization for production visuals.

Phase 39 introduces an optional, execution-side canvas contract used only when
callers explicitly request production materialization.  It does not change
VisualPlan semantics or provider prompts.  The normalizer performs local
Pillow-only post-processing so every rendered still handed to the video layer
can share one exact canvas size.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path

from PIL import Image, ImageColor, UnidentifiedImageError
from pydantic import model_validator

from app.models.common import MotilyModel, VisualMediaType


class VisualCanvasFit(str, Enum):
    COVER = "COVER"
    CONTAIN = "CONTAIN"


class VisualCanvasSpec(MotilyModel):
    width: int = 1280
    height: int = 720
    background_color: str = "#F4F0E8"

    @model_validator(mode="after")
    def _check(self) -> "VisualCanvasSpec":
        if self.width <= 0 or self.height <= 0:
            raise ValueError("width/height must be > 0")
        try:
            ImageColor.getrgb(self.background_color)
        except ValueError as exc:
            raise ValueError(f"invalid background_color {self.background_color!r}") from exc
        return self


class VisualCanvasError(Exception):
    pass


def fit_for_media_type(media_type: VisualMediaType) -> VisualCanvasFit:
    """Fixed production policy: explanatory/canonical graphics are never
    cropped; scene-like stills may fill the frame by center crop."""
    if media_type in {VisualMediaType.DIAGRAM, VisualMediaType.TI_STATE}:
        return VisualCanvasFit.CONTAIN
    return VisualCanvasFit.COVER


def normalize_raster_file(
    path: Path,
    *,
    spec: VisualCanvasSpec,
    media_type: VisualMediaType,
) -> tuple[int, int]:
    """Normalize *path* in-place atomically to ``spec``.

    Output format follows the file suffix (.png/.jpg/.jpeg).  Alpha from an
    input PNG is composited over ``background_color`` because the downstream
    H.264/yuv420p pipeline is opaque.
    """
    if not path.is_file():
        raise VisualCanvasError(f"visual file not found: {path}")
    try:
        source = Image.open(path)
        source.load()
    except (UnidentifiedImageError, OSError) as exc:
        raise VisualCanvasError(f"failed to decode visual file {path}: {exc}") from exc

    image = source.convert("RGBA")
    target = (spec.width, spec.height)
    fit = fit_for_media_type(media_type)
    bg_rgb = ImageColor.getrgb(spec.background_color)

    if fit is VisualCanvasFit.COVER:
        scale = max(spec.width / image.width, spec.height / image.height)
        resized = image.resize(
            (max(1, round(image.width * scale)), max(1, round(image.height * scale))),
            Image.Resampling.LANCZOS,
        )
        left = max(0, (resized.width - spec.width) // 2)
        top = max(0, (resized.height - spec.height) // 2)
        fitted = resized.crop((left, top, left + spec.width, top + spec.height))
        canvas = Image.new("RGBA", target, (*bg_rgb, 255))
        canvas.alpha_composite(fitted, (0, 0))
    else:
        scale = min(spec.width / image.width, spec.height / image.height)
        resized = image.resize(
            (max(1, round(image.width * scale)), max(1, round(image.height * scale))),
            Image.Resampling.LANCZOS,
        )
        canvas = Image.new("RGBA", target, (*bg_rgb, 255))
        x = (spec.width - resized.width) // 2
        y = (spec.height - resized.height) // 2
        canvas.alpha_composite(resized, (x, y))

    suffix = path.suffix.lower()
    if suffix == ".png":
        output = canvas.convert("RGBA")
        fmt = "PNG"
    elif suffix in {".jpg", ".jpeg"}:
        output = canvas.convert("RGB")
        fmt = "JPEG"
    else:
        raise VisualCanvasError(f"unsupported visual suffix for canvas normalization: {suffix!r}")

    tmp = path.with_name(path.name + ".canvas.tmp")
    try:
        output.save(tmp, format=fmt, quality=95 if fmt == "JPEG" else None)
        tmp.replace(path)
    except OSError as exc:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        raise VisualCanvasError(f"failed to write normalized visual {path}: {exc}") from exc
    return target


def create_solid_canvas(path: Path, spec: VisualCanvasSpec) -> None:
    """Create one opaque deterministic support canvas for standalone Tí."""
    rgb = ImageColor.getrgb(spec.background_color)
    image = Image.new("RGB", (spec.width, spec.height), rgb)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        image.save(tmp, format="PNG")
        tmp.replace(path)
    except OSError as exc:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        raise VisualCanvasError(f"failed to create standalone Tí canvas {path}: {exc}") from exc
