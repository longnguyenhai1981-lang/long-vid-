"""Deterministic evidence-media binding/materialization helpers.

Keep package import side-effect-free: renderer code imports only
app.evidence_media.models and must not transitively load LLM-backed engines.
"""
