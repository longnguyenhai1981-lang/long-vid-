"""Deterministic fake HeroVideoProvider for tests."""

from collections.abc import Sequence

from app.hero_video.errors import HeroVideoProviderError
from app.hero_video.models import HeroVideoRenderRequest, HeroVideoRenderResponse


class FakeHeroVideoProvider:
    def __init__(self, responses: Sequence[HeroVideoRenderResponse | Exception]):
        self._responses = list(responses)
        self.received_requests: list[HeroVideoRenderRequest] = []

    def render(self, request: HeroVideoRenderRequest) -> HeroVideoRenderResponse:
        self.received_requests.append(request)
        index = len(self.received_requests) - 1
        if index >= len(self._responses):
            raise HeroVideoProviderError(
                f"FakeHeroVideoProvider exhausted: no response configured for call {index + 1}"
            )
        item = self._responses[index]
        if isinstance(item, Exception):
            raise item
        return item

    @property
    def call_count(self) -> int:
        return len(self.received_requests)
